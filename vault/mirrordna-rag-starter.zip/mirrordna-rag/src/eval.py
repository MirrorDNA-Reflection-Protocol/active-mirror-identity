
import time
from query import answer

QUESTIONS = [
  "What is MirrorDNA?",
  "Define Trust by Design.",
  "List the Beacon Glyphs.",
  "How do we vault and fingerprint drops?",
  "What is the Seduction Audit?"
]

def run_eval():
    hits=0; cited=0; t0=time.time()
    for q in QUESTIONS:
        t1=time.time()
        out, ctx = answer(q)
        took = time.time()-t1
        if "Not in Vault" not in out: hits+=1
        if "[" in out and "]" in out: cited+=1
        print(f"Q: {q}\n→ {out[:220]}...\n({took:.2f}s)\n")
    print(f"Hit-rate: {hits}/{len(QUESTIONS)}")
    print(f"Cited answers: {cited}/{len(QUESTIONS)}")
    print(f"Total time: {time.time()-t0:.2f}s")

if __name__ == "__main__":
    run_eval()
