# MirrorDNA RAG — v0

Local retrieval-augmented Q&A over your Obsidian Vault.

## Quickstart
```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
# put markdown files into ./data
python src/ingest.py
python src/query.py "What is Trust by Design?"
python src/serve.py
python src/eval.py
```

## Config
Edit `configs/config.yaml`. Switch between local Ollama and OpenAI API.

## Metrics (fill after eval)
- Date: 2025-08-20
- Hit-rate: __ / 5
- Cited answers: __ / 5
- Avg latency: __ sec
