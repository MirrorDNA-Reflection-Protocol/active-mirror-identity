# Mom Profile Loader v1

What this is
- A tiny kit to inject Ami's persistent profile into any AI session.

Files
- system_prompt_ami.txt — copy/paste into a System Prompt (ChatGPT/Claude/etc.).
- load_mom_profile.py — outputs a ready-to-use system message for OpenAI or Claude.
- (expects) Mom_Profile_Persistent.json — the profile JSON (place alongside this folder).

Quick use
1) Copy Mom_Profile_Persistent.json into this folder.
2) OpenAI style:
   python load_mom_profile.py --profile Mom_Profile_Persistent.json --target openai > system_message.json
   # Then include system_message.json in your API call.
3) Claude style:
   python load_mom_profile.py --profile Mom_Profile_Persistent.json --target anthropic > system.txt
   # Paste system.txt into Claude's "system" area.
4) Plain copy/paste:
   open system_prompt_ami.txt and paste into any model's system field.

Notes
- The prompt enforces kidney-safe, calm pacing, and consent-first memory.
- Never store PII without explicit consent.
