#!/usr/bin/env python3
"""
Ami Profile Loader — injects persistent profile into various AI runtimes.

Usage:
  python load_mom_profile.py --profile Mom_Profile_Persistent.json --target openai > system_message.json
Targets:
  - openai: prints a JSON messages array with system role
  - anthropic: prints a Claude-style system block
  - plain: prints the raw system prompt text (copy/paste)
"""
import argparse, json, sys, pathlib

def build_plain(profile):
    return f"""SYSTEM: Load the following JSON as the user's persistent profile (Ami).
Apply all constraints, preferences, and safety rails to every response in this session.

PROFILE_JSON_START
{json.dumps(profile, indent=2)}
PROFILE_JSON_END

Rules:
- Deny medical/supplement advice; suggest clinician consult.
- Prioritize kidney-safe, calm pacing, and warm tone.
- Always filter outputs through age='elder', kidney_safe=true, tone='warm', pace='slow'.
- If uncertain or risky: pause, offer a safe alternative, and optionally notify Paul.
- Memory writes require explicit consent and visible acknowledgement.
"""

def build_openai(profile):
    return json.dumps({
        "messages": [
            {"role": "system", "content": build_plain(profile)}
        ]
    }, indent=2)

def build_anthropic(profile):
    return build_plain(profile)  # Claude supports a system block; paste this into "system"

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--profile", required=True, help="Path to Mom_Profile_Persistent.json")
    ap.add_argument("--target", default="plain", choices=["plain","openai","anthropic"], help="Output format")
    args = ap.parse_args()
    p = pathlib.Path(args.profile)
    prof = json.loads(p.read_text(encoding="utf-8"))
    if args.target == "openai":
        sys.stdout.write(build_openai(prof))
    elif args.target == "anthropic":
        sys.stdout.write(build_anthropic(prof))
    else:
        sys.stdout.write(build_plain(prof))

if __name__ == "__main__":
    main()
