#!/usr/bin/env python3
# demos/demo_sync.py
import argparse, importlib, json, sys

vs = importlib.import_module('vault_sync_layer')

if __name__ == "__main__":
    p = argparse.ArgumentParser(description="MLP demo — compare manifests and print diffs")
    p.add_argument("local_dir", help="path to local vault dir")
    p.add_argument("remote_dir", help="path to remote vault dir (simulated)")
    args = p.parse_args()

    local = vs.build_manifest(args.local_dir)
    remote = vs.build_manifest(args.remote_dir)

    diffs = vs.diff(local, remote)
    print(json.dumps({"local_files": len(local["files"]), "remote_files": len(remote["files"]), "diff_paths": diffs}, indent=2))
