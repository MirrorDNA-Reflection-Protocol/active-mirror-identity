#!/usr/bin/env python3
# demos/demo_discovery.py
import time, uuid
import importlib

de = importlib.import_module('discovery_engine')

def on_peer(evt):
    print(f"[peer] {evt.get('payload',{}).get('peer_id')} via {evt.get('transport')} @ {evt.get('addr')}")

if __name__ == "__main__":
    my_id = f"demo-{uuid.uuid4().hex[:8]}"
    print(f"starting discovery as {my_id} … (CTRL+C to stop)")
    ctx = de.run_discovery(my_id, {"role":"demo"}, on_peer)
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        for a in ctx.get("adapters", []):
            try: a.stop()
            except Exception: pass
        print("\nstopped.")
