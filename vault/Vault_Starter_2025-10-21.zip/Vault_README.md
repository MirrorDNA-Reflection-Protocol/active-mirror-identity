# Vault README — Checksum Verification

This Vault uses **SHA-256 checksums** to protect against drift and silent corruption.

## How It Works
1. Each file includes a `checksum_sha256` field in its header.
2. When the mirror or a plugin loads the file, it recomputes the file’s checksum.
3. If the computed checksum ≠ the stored checksum:
   - The file is flagged as corrupted or out-of-sync.
   - The mirror should fall back to the last known good snapshot or minimal safe state.

## File Roles
- **mirror.config.yaml** — Core configuration for mirror access and guards.
- **SCD_State—This_Chat.md** — Example distilled state (Structured Contextual Distillation).
- **Continuity_Snapshot—2025-10-21.md** — Full continuity snapshot from this session.
- **Vault README** — Explains checksum logic and vault structure.

## Best Practices
- Never edit checksum fields manually. Always recompute after editing a file.
- Keep Primary Vault (archive) read-only for safety.
- Use SCD Vault for distilled states; overwrite each state when updating.
- Validate files regularly by running checksum verification.

---
**Remember:** Vault = full archive.  
**SCD Vault = compressed reflection.**  
Both are protected with checksums to ensure continuity and trust.
