# MirrorDNA DropKit v1.7 — Trademark-Integrated
Date: 2025-08-14

This release bakes **AgentDNA™**, **GlyphTrail™**, and **Reflective AI Protocol™** into every artifact via a legal and operational anchor.

## What’s new
- `/legal/Trademark_Anchor_Module.md` — include in every new file.
- `/policies/protected_constructs.json` — prevents silent redefinition.
- `/glyphs/Beacon_Glyphs_Registry_v1.md` — trademark-aware glyph anchors.

## How to apply
1) Add the Trademark Anchor block to headers of new `.md`/`.txt` files.
2) Import `protected_constructs.json` into your policy bundle and enforce `deny_redefinition` in CI.
3) Reference the glyphs for agent init (AgentDNA™), provenance (GlyphTrail™), and reflection (Reflective AI Protocol™).

## CI tip
Fail CI if `protected_constructs.json` is missing or modified without owner consent.
