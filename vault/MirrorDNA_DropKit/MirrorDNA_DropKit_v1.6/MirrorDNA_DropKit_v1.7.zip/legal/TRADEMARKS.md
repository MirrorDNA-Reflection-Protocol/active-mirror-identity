# Trademarks & Usage — MirrorDNA DropKit v1.7
**Date:** 2025-08-14

- AgentDNA™ — operational identity layer for agents (ownership: Paul Desai)
- GlyphTrail™ — symbolic trace of actions/decisions across time (ownership: Paul Desai)
- Reflective AI Protocol™ — governance for recursive reflection cycles (ownership: Paul Desai)

**Usage:** Mark ™ on first use per artifact. Include the Trademark Anchor Module in all new `.md`/`.txt` files.
**Redistribution:** Allowed with attribution; derivations must retain authorship lineage in headers.
