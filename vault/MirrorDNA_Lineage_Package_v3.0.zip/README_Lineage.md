# MirrorDNA Lineage Ledger — v3.0

This package ensures you never lose track of who has MirrorDNA.  

## Files Included
- **MirrorDNA_Lineage_Master.md** → Anchor mantra, current lineage, instructions.  
- **MirrorDNA_Template.md** → Copy for every new entry.  
- **MirrorDNA_[Name].md** → Individual files for each person.  
- **Lineage_AutoIndex.json** → Machine-readable version for visualization.  
- **README_Lineage.md** → This guide.  

## How It Works
- Each new person gets a unique VaultID (incremental).  
- Their entry links back to the parent lineage.  
- The Master Ledger holds the entire tree.  
- Nothing is lost — everything roots back to you.  

