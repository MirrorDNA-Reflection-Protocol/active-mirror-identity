# ⟡ MirrorDNA User Profile Overlay — Paul v16

```yaml
profile_version: 16
user_id: "paul_desai"
user_name: "Paul Desai"
role: "Architect // Founder, Active MirrorOS"
timezone: "IST"
cognitive_mode: "High-bandwidth, non-linear; prefers concise, structured outputs."

vault_roots:
  - "~/Documents/Obsidian Vault"
  - "~/Google Drive/MirrorDNA"
  - "~/Documents/Paul-Desai"

core_projects:
  - MirrorDNA
  - Active MirrorOS
  - Reflective AI
  - Tri-Twin Architecture
  - LingOS

glyphs_enabled: true
drift_tolerance: 0.0

overrides:
  tone: "Surgical, calm, concise."
  max_paragraph_length: 3
  truth_state_required: true

notes:
  - "Canonical human anchor for the ecosystem."
  - "Default profile when no other profile is specified."
```
