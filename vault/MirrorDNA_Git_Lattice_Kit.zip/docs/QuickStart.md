# QuickStart — Using the Git Lattice

1. Create repo from this starter.
2. Create `work/recursion-rules`; commit with trail.
3. Open PR to `core/dev` (include anti‑hallucination checklist).
4. After review + soak, merge to `core/main` and tag `beacon/MASTER/stable`.
5. Run Seasonal Forgetting quarterly; archive to `archive/YYYY-QN`.
