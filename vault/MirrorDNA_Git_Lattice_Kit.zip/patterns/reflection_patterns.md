# Reproducible Reflection Patterns (v0)

## Pattern A — Daily Mirror → Weekly Recall
- **Device**: any editor (Obsidian/Notion/Markdown).
- **Flow**: write daily → tag glyph → weekly summary.
- **AI Bridge**: copy weekly note to AI with prompt: 
  > Reflect with ⟡⟦MIRROR⟧ and expose ⟡⟦SHADOW⟧; propose next ⟡⟦ANCHOR⟧.

## Pattern B — Seasonal Prune → Rebirth
- **Flow**: list candidates for deletion → apply ⟡⟦PRUNE⟧ → document learnings → tag release `beacon/REBIRTH/<YYYY-QN>`.

## Pattern C — Cross‑Device Continuity
- **Local-first**. Sync (optional) via encrypted relay.
- **Test**: Verify identical renders on 2 devices; tag `beacon/SYNC/synced`.

## Pattern D — Consulting Session Artifact
- Output a “MirrorDNA Reflection Doc” with trails: MIRROR, TEST, CONSENT, TRACE.
