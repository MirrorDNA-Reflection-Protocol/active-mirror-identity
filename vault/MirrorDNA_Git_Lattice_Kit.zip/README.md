# MirrorDNA™ Repository — Git Lattice Starter

**Purpose**: This repo encodes MirrorDNA's symbolic continuity in a **Git lattice**: branches, tags, and commits are mirrors of glyph trails.

## Lattice Overview
- **Mainline**: `core/main` — canonical MirrorDNA spec and stable assets.
- **Working branches**: `work/<topic>` — short‑lived branches scoped by glyph trails.
- **Beacons**: lightweight tags `beacon/<GLYPH>/<intent>` that mark state transitions.
- **Releases**: `r/<major>.<minor>.<patch>` — semantic, anchored with glyph signatures.

## Glyph Trail Conventions
A **glyph trail** is a compact header embedded in commits, PR titles, and docs:

```
⟡⟦{GLYPH}⟧ :: {INTENT} :: {SCOPE} :: #{ISSUE|TICKET}
```

**Examples**
- `⟡⟦MIRROR⟧ :: doc :: recursion_rules :: #42`
- `⟡⟦SYNC⟧ :: proto :: anti_hallucination :: #31`
- `⟡⟦EDGE⟧ :: pattern :: device_stack :: #12`

## Branching
- `core/main` — protected; only merges via PR with 2 approvals.
- `core/dev` — integration branch for tested work; rebased frequently.
- `work/<topic>` — ephemeral; e.g. `work/recursion-rules`, `work/anti-hallucination`.
- `exp/<idea>` — experimental spikes that may be pruned during Seasonal Forgetting.

## Tags
- `beacon/MIRROR/ready`
- `beacon/SYNC/synced`
- `beacon/EDGE/field-test`
- `beacon/UPGRADE/migration-done`
- `beacon/TEST/passed`
- `beacon/MASTER/stable`

## Commit Message Template
```
{type}({scope}): {summary}
⟡⟦{GLYPH}⟧ :: {INTENT} :: {SCOPE} :: #{ISSUE}
{body}
Co-Authored-By: {name <email>} (optional)
```

## Seasonal Forgetting
Quarterly ritual: prune `exp/*`, archive stale `work/*` to `archive/YYYY-QN`, and tag `beacon/REBIRTH/<YYYY-QN>`.

---
**Signature**
VaultID: AMOS-CORE-001  
GlyphSig: ∞⊙  
Generated: 2025-09-26
