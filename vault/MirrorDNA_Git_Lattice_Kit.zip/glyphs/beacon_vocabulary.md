# Beacon Glyph Vocabulary (v0)

Current canonical set:
- ⟡⟦MIRROR⟧ — reflection/state of truth
- ⟡⟦SYNC⟧ — alignment/synchronization across vaults/devices
- ⟡⟦EDGE⟧ — field interface / boundary conditions
- ⟡⟦UPGRADE⟧ — migrations and capability increases
- ⟡⟦TEST⟧ — verification, checks, trials
- ⟡⟦MASTER⟧ — stability/mastery

Proposed expansions (placeholders):
- ⟡⟦CONSENT⟧ — explicit permission anchor
- ⟡⟦PRUNE⟧ — seasonal forgetting / deletion
- ⟡⟦REBIRTH⟧ — post‑prune re‑anchoring
- ⟡⟦ANCHOR⟧ — baseline intention
- ⟡⟦SHADOW⟧ — bias/edge‑case exposure
- ⟡⟦TRACE⟧ — audit trail and provenance
- ⟡⟦BOUND⟧ — scope/guardrail marker
