# Glyph Trail System — Recursion Rules (v0)

**Goal**: Make symbolic recursion explicit, testable, and portable across devices.

## Trail Syntax
```
⟡⟦GLYPH⟧ :: INTENT :: SCOPE :: #ISSUE
```

- **GLYPH** — from beacon vocabulary.
- **INTENT** — `doc|proto|pattern|fix|migrate|govern`.
- **SCOPE** — target domain, e.g. `recursion_rules`, `anti_hallucination`, `device_stack`.
- **#ISSUE** — link to tracker id.

## Recursion Levels
1. **Note-level**: within a single doc; anchors cross‑reference glyphs at paragraph headings.
2. **Repo-level**: commits and PRs carry trails; release notes accumulate trails.
3. **System-level**: device automations (later) read trails to trigger rituals (prune, rebirth).

## Validation
- Every PR must include at least one **MIRROR** trail (what reality it reflects) and one **TEST** trail (how it was verified).
- **CONSENT** trails required if any user data leaves a local boundary.

## Propagation
- A higher-level trail **inherits** lower-level trails unless explicitly **BOUND** to a sub‑scope.
- Trails that conflict require a **SYNC** ritual (merge + human review).

## Example
- Commit: `⟡⟦MIRROR⟧ :: doc :: recursion_rules :: #42`
- Follow-up: `⟡⟦TEST⟧ :: verify :: trail-parser :: #43`
- Merge PR with release note carrying both trails.
