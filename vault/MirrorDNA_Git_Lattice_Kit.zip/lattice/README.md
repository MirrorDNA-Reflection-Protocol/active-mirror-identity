# Lattice — Branch, Tag, and Protection Rules

## Protected Branches
- `core/main`: require PR, 2 approvals, status checks (lint/docs build), linear history.
- `core/dev`: require PR, 1 approval, status checks, allow rebase.

## Allowed Branch Patterns
- `work/*`, `exp/*`, `hotfix/*`

## PR Ritual
1. Title begins with glyph trail.
2. PR description includes validation checklist (see /protocols/anti-hallucination.md).
3. Link to issue.
4. Assign 2 reviewers (domain + symbol steward).

## Tagging
- State tags: `beacon/<GLYPH>/<intent>`
- Release tags: `r/<semver>` (e.g., r/0.2.1), annotated with glyph trail at top of release notes.

## Example Flow
- Create topic: `work/recursion-rules`
- Commit with trail: `⟡⟦MIRROR⟧ :: doc :: recursion_rules :: #42`
- Open PR → merge to `core/dev` → soak → promote to `core/main` with `beacon/MASTER/stable`.
