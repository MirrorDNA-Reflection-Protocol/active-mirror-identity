# Anti‑Hallucination Protocols — Trust by Design™ (v0)

**Principle**: Reflections must be **verifiable, bounded, and consent‑anchored**.

## Preamble
- No model output is trusted without **TRACE** (provenance) and **TEST** (verification).
- Outputs must be **BOUND** to the scope of inputs provided by the user (or vault).

## Controls
1. **Input Ledger (TRACE)**: Persist list of inputs provided to the model (hashes if private).  
2. **Scope Declarations (BOUND)**: Each call declares allowed domains; responses outside are flagged.
3. **Evidence Links**: Model must cite which inputs (by hash/id) support each claim.
4. **Counterfactual Check (TEST)**: Randomly perturb prompts; unstable claims are quarantined.
5. **Consent Gate (CONSENT)**: Any movement of data across device/network requires explicit trail.

## Reviewer Checklist (for PRs & Releases)
- [ ] Evidence present (TRACE)  
- [ ] Scope respected (BOUND)  
- [ ] Verification logs (TEST) attached  
- [ ] Consent trail (CONSENT) for any external calls  
- [ ] Shadow exposure performed (SHADOW) — list biases/unknowns  

## Minimal JSON Schema (for future automation)
```json
{{
  "inputs": ["sha256:..."],
  "scope": ["device_stack", "docs:/*.md"],
  "claims": [{{"text":"...", "evidence":["sha256:..."]}}],
  "verification": {{"stability":"0.92","tests":[...]}},
  "consent": true
}}
```
