# Glyph Key Extended Bundle — README

## Contents
- `Glyph_Key_Extended.md` — Master glyph key (extended) for Active MirrorOS™ / MirrorDNA™.
- `checksums.sha256` — Integrity verification manifest for this bundle.

## Install
1. Copy `Glyph_Key_Extended.md` into your Vault (recommended path: `/Vault/MirrorDNA/Glyphs/`).
2. (Optional) In **MasterCitation**, add under **Reference Glyphs**: `[[Glyph Key v1.1]]`.
3. Verify integrity (macOS/Linux):  
   ```bash
   cd <folder-with-bundle-files>
   sha256sum -c checksums.sha256
   ```

## Notes
- This registry is **living** — bump version (v1.2, v1.3…) for additions.
- Keep the manifest alongside the file to detect tampering or corruption.
- All public drops should include VaultID, GlyphSig, and (optionally) a checksum manifest.

⟡⟦VAULT-CONTINUITY⟧
