---
vault_id: MDNA-LAGxGEPA-v1
glyphsig: "Reasoned Evolution Seal ⟲⊕"
title: LAG × GEPA → MirrorDNA Reasoning + Adaptation Stack
---

## Goal
Think better (logic), evolve faster (prompt adaptation), stay sovereign (Vault truth).

## Architecture (thin + local-first)
- **⊕ Logic Layer (LAG-style)**: Decompose → order by dependencies → solve sequentially → integrate.
- **⟲ Adaptation Layer (GEPA-style)**: Mutates prompt scaffolds per task + feedback, no base-model retrain.
- **◆ Vault Router**: Pulls only relevant notes/snippets; enforces consent + provenance.
- **✓ Verifier**: Unit-checks each sub-answer against Vault facts + constraints.
- **Δ Reflection Loop**: Logs errors, wins, drift; feeds Adaptation Layer.

## Control Flow (FAST)
1. Parse query → build Logic Graph (nodes=sub-questions, edges=deps).
2. Retrieve minimal Vault shards per node (◆).
3. Solve node i → Verify ✓ → cache.
4. On fail/low confidence → Adapt ⟲ micro-prompt for that node only.
5. Compose final → Reflect Δ → store fingerprints.

## Scaffolds
**Logic Decomposer (prompt)**
```
Task: split into atomic sub-questions with explicit dependencies.
Return JSON: [{id, text, needs:[ids], type:fact|judgment|plan}]
Guard: prefer ≤5 nodes; no orphan nodes; no cycles.
```

**Node Solver (prompt)**
```
You are solving node {id}:{text}
Dependencies resolved: {summaries}
Use ONLY: {vault_snippets}
If insufficient, return "NEEDS_MORE" and ask one precise retrieval.
Output: {claim, reasoning(≤5 lines), confidence 0-1, citations}
```

**GEPA Micro-Adapt (prompt)**
```
Given node history {fail_reason, prior_prompt, vault_snippets},
generate a lighter variant prompt with 1-2 constraint tweaks.
Goal: resolve the blockage without expanding scope.
```

**Verifier (rules)**
- Fact nodes: must cite Vault lines; no cite → fail.
- Judgment/plan: must list assumptions; non-vault assumptions tagged [Estimate].
- Any external claim → blocked unless user grants.

## Minimal Offline Setup (Pixel / LM Studio)
- Model: small instruct LLM (e.g., Q4_K_M).
- Router: simple Python; retrieval via local SQLite/FAISS on Vault.
- Files:
  - /prompts/logic_decomposer.txt
  - /prompts/node_solver.txt
  - /prompts/micro_adapt.txt
  - /rules/verifier.yaml

## Trust-By-Design
- Fingerprint each node result: {hash(vault_snips)+prompt_id+model_id}.
- Log to LAGxGEPA_Trace.log with timestamps + outcomes.
- Deny compose if any node confidence <0.6 or missing cite.

## Tiny Example
Query: “Draft a hiring plan for a values-aligned PM in 30 days.”
Nodes:
1. Define alignment criteria (needs: Vault values) — fact
2. Role scorecard — fact/judgment
3. 30-day plan — plan

Fail at Node2? GEPA mutates: add constraint “evidence from past projects in Vault” → retry.

## Metrics
- Δ-Error: # node fails before/after adaptation.
- Logic Depth: max path length.
- Cite Integrity: % fact nodes with Vault lines ≥1.
- Time-to-First-Draft per query.

## Activation Whisper
> “Guide, engage — reason first, then evolve. Seal drift, adapt the scaffold.”
