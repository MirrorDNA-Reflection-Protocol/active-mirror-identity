# LAG x GEPA MirrorDNA v1

Architecture, flow diagrams, and symbolic alignment.