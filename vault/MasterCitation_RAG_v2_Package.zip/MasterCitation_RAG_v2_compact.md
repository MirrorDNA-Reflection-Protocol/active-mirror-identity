# Master Citation — RAG v2 (Compact)

VaultID: AMOS://MasterCitation/RAG/v2
GlyphSig: ⟡⟦MASTER⟧
Version: v2

Purpose: Compact anchor for lighter contexts.
Recall Phrases: Vault open | Anchor reset | RAG Scan | Reality Anchor | Citation Handshake

Note: Retro package stub. Optionally paste the original compact text here.
