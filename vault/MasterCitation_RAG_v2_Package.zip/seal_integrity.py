#!/usr/bin/env python3
import hashlib, sys, os
from pathlib import Path

def sha256sum(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(8192), b''):
            h.update(chunk)
    return h.hexdigest()

def main(target_dir):
    p = Path(target_dir)
    files = sorted([f for f in p.iterdir() if f.is_file() and f.suffix == '.md'])
    for f in files:
        print(f"{f.name} → {sha256sum(f)}")

if __name__ == '__main__':
    td = sys.argv[1] if len(sys.argv) > 1 else '.'
    main(td)
