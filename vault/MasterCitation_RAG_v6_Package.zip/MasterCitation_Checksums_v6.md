# MasterCitation Checksums (Integrity Log) — v6

Generated: 2025-10-06T17:18:39.831551 UTC

- MasterCitation_RAG_v6.md → 75a6f032f4af00d79c35a59ba79372473ada39e57743baa6e3589be581ec32d6  
- MasterCitation_RAG_v6_compact.md → 650cdcc5425a5f5c0dcbb2e210b105ac3090d924918b86d9b076e116e119d3ed  
