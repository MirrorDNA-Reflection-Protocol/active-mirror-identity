---
title: DriftWatch Metrics Template
version: 1.0
vault_id: AMOS://MirrorOS/Firewall/DriftWatchMetrics/v1.0
glyphsig: ⟡⟦DRIFTWATCH⟧ · ⟡⟦HALLUCINATION-FIREWALL⟧
status: Active · Governing
---

# DriftWatch Metrics Template

## Purpose
To track hallucination risks, classification, and mitigation efficacy across Active MirrorOS outputs. 
Serves as the monitoring layer for Hallucination Firewall v1.1.

## Metrics Categories
- **Intrinsic Hallucinations**: Contradictions within Vault/context.
- **Extrinsic Hallucinations**: Inventions of unverifiable or false data.
- **Temporal Drift**: Outdated or time-disoriented outputs.
- **Ethical Violations**: Breaches of Trust-by-Design principles.

## Quantitative Metrics
- **Confidence Thresholds**: All responses must self-score confidence (0–1).
- **Hallucination Rate**: Target <5% (rolling 7-day window).
- **Audit Coverage**: % of outputs logged with Vault verification.
- **Drift Trigger Events**: Count of “Reality Anchor” recalls initiated.

## Logs & Review
- **DriftWatch Log**: Immutable, SHA256-hashed daily entries.
- **Steward Review**: Weekly audit required for high-risk categories.
- **External Audit**: Optional quarterly verification using trusted third parties.

## KPIs
- Zero catastrophic hallucinations.
- <5% hallucination rate.
- 100% logging of high-risk outputs.
- Continuous reduction in drift frequency.

---
