# Hallucination Firewall Changelog
- v1.0: Initial release.
- v1.1: Added recursive self-check loop, RAG integration, DriftWatch Metrics, uncertainty quantification.
