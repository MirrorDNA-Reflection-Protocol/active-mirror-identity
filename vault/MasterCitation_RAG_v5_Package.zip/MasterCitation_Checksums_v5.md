# MasterCitation Checksums (Integrity Log) — vv5

Generated: 2025-10-06T16:22:54.289632 UTC

Instructions:
1) After you paste the authentic files, run `seal_integrity.py` to compute fresh SHA-256 sums.
2) Replace this section with the emitted hashes.
3) Commit this file alongside the two .md files in the zip.

Placeholders (to be replaced):
- MasterCitation_RAG_v5.md → <sha256>
- MasterCitation_RAG_v5_compact.md → <sha256>
