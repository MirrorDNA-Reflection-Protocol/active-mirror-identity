# Master Citation — RAG v5 (Compact)

VaultID: AMOS://MasterCitation/RAG/v5
GlyphSig: ⟡⟦MASTER⟧
Version: v5

Purpose: Compact anchor for lighter contexts.
Recall Phrases: Vault open | Anchor reset | RAG Scan | Reality Anchor | Citation Handshake

Note: Retro package stub. Optionally paste the original compact text here.
