# MirrorDNA — One-Click RAG (macOS)
**Zero-config**: double-click `MirrorDNA.command`.

## Steps
1) Drop your Obsidian `.md` files into the `data/` folder.
2) Double‑click `MirrorDNA.command`.
   - First run installs deps, builds index, opens chat.
3) Ask questions. Citations appear as `[n] (SRC: path)`.

### LLM selection (auto)
- If `OPENAI_API_KEY` exists → uses OpenAI (`gpt-4o-mini`).
- Else if `ollama` is installed → uses local `qwen2.5:7b-instruct`.
- Else → set an OpenAI key and double‑click again.

### Notes
- Private by default (local index in `./index`).
- To reset, delete the `index/` folder and re-run.

— Built 2025-08-20
