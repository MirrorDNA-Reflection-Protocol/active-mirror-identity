#!/bin/bash
# MirrorDNA One-Click (macOS)
set -e

cd "$(dirname "$0")"

# Open a new Terminal window if not already interactive
if [ -z "$TERM_PROGRAM" ]; then
  osascript -e 'tell application "Terminal" to do script "cd \"'$PWD'\" && ./MirrorDNA.command"'
  exit 0
fi

echo "⧉ MirrorDNA — One-Click RAG"
echo "Checking Python venv..."
if [ ! -d ".venv" ]; then
  python3 -m venv .venv
fi
source .venv/bin/activate

echo "Installing deps (first run may take a few minutes)..."
pip install -r requirements.txt -q

echo "Ensuring data exists... (put your Obsidian .md files in ./data)"
mkdir -p data index

echo "Building index..."
python src/ingest.py || { echo "No markdown found in ./data. Add files and double-click again."; exit 2; }

echo "Launching chat..."
python src/serve.py
