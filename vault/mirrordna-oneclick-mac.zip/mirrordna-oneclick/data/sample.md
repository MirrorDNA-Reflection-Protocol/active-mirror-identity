# MirrorDNA Sample
Trust by Design = memory + consent + provenance.
