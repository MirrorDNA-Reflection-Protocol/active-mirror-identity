
import os, glob, yaml, json
from pathlib import Path
from sentence_transformers import SentenceTransformer
import faiss
from rich import print

cfg = yaml.safe_load(open("configs/config.yaml"))
VAULT = Path(cfg["paths"]["vault_dir"])
INDEX = Path(cfg["paths"]["index_dir"]); INDEX.mkdir(exist_ok=True, parents=True)

def load_docs(vault_dir):
    files = glob.glob(str(Path(vault_dir) / "**/*.md"), recursive=True)
    docs=[]
    for fp in files:
        try:
            text = Path(fp).read_text(encoding="utf-8", errors="ignore")
            docs.append({"path": fp, "text": text})
        except Exception as e:
            print(f"[yellow]Skip {fp}: {e}[/yellow]")
    return docs

def chunk(text, size=900, overlap=150):
    out=[]; i=0
    while i < len(text):
        out.append(text[i:i+size])
        i += max(1, size - overlap)
    return [c for c in out if c.strip()]

def build_index():
    print("[cyan]Loading docs...[/cyan]")
    raw = load_docs(VAULT)
    if not raw:
        print("[red]No markdown files found in ./data[/red]"); return False
    print(f"[green]Docs:[/green] {len(raw)}")

    print("[cyan]Embedding...[/cyan]")
    model = SentenceTransformer(cfg["embedding_model"])
    chunks, meta = [], []
    for d in raw:
        for c in chunk(d["text"], cfg["chunk_size"], cfg["chunk_overlap"]):
            chunks.append(c); meta.append({"path": d["path"][:256]})
    X = model.encode(chunks, batch_size=64, show_progress_bar=True, normalize_embeddings=True)

    print("[cyan]Building FAISS index...[/cyan]")
    idx = faiss.IndexFlatIP(X.shape[1]); idx.add(X)
    faiss.write_index(idx, str(INDEX / "faiss.index"))
    (INDEX / "meta.json").write_text(json.dumps({"chunks": chunks, "meta": meta}), encoding="utf-8")
    print(f"[green]Indexed chunks:[/green] {len(chunks)}")
    return True

if __name__ == "__main__":
    ok = build_index()
    if not ok:
        exit(2)
