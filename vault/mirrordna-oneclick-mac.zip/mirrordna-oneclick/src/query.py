
import json, yaml, faiss, shutil
from sentence_transformers import SentenceTransformer
from pathlib import Path
import subprocess, os, sys

cfg = yaml.safe_load(open("configs/config.yaml"))
INDEX = Path(cfg["paths"]["index_dir"])
model = SentenceTransformer(cfg["embedding_model"])
faiss_idx = faiss.read_index(str(INDEX / "faiss.index"))
store = json.loads((INDEX / "meta.json").read_text())
chunks, meta = store["chunks"], store["meta"]

def detect_llm_mode():
    auto = cfg["llm"]["mode"] == "auto"
    if not auto: return cfg["llm"]["mode"]
    if os.getenv("OPENAI_API_KEY"): return "openai"
    if shutil.which("ollama"): return "ollama"
    return "openai"  # default if user sets key later

def retrieve(q, k=6):
    qv = model.encode([q], normalize_embeddings=True)
    D, I = faiss_idx.search(qv, k)
    return [(chunks[i], meta[i]["path"], float(D[0][j])) for j,i in enumerate(I[0])]

def synthesize_llm(prompt):
    mode = detect_llm_mode()
    if mode == "ollama":
        m = cfg["llm"]["model"]
        p = subprocess.run(
            ["ollama","run", m],
            input=prompt.encode(), capture_output=True
        )
        return p.stdout.decode() or p.stderr.decode()
    else:
        try:
            from openai import OpenAI
            client = OpenAI()
            r = client.chat.completions.create(
                model="gpt-4o-mini",
                messages=[{"role":"user","content":prompt}],
                temperature=0.2
            )
            return r.choices[0].message.content
        except Exception as e:
            return f"[LLM error] {e}"

def answer(q):
    hits = retrieve(q, cfg["top_k"])
    ctx = "\n\n".join([f"[{i+1}] {h[0]}\n(SRC: {h[1]})" for i,h in enumerate(hits)])
    prompt = f\"\"\"You are a precise MirrorDNA RAG assistant.
Answer the question using ONLY the context. Cite sources as [#] with path.

Question: {q}

Context:
{ctx}

If unknown, say "Not in Vault".
\"\"\"
    out = synthesize_llm(prompt)
    return out, hits

if __name__ == "__main__":
    q = " ".join(sys.argv[1:]) or "What is Trust by Design?"
    out, _ = answer(q)
    print(out)
