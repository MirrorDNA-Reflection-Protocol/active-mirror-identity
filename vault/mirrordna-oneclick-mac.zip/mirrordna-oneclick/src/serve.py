
from query import answer
from rich.prompt import Prompt
from rich import print

def main():
    print("[bold magenta]MirrorDNA — One-Click RAG[/bold magenta]  (type 'exit' to quit)")
    while True:
        q = Prompt.ask("[cyan]Ask[/cyan]")
        if q.strip().lower() in {"exit","quit"}: break
        out, _ = answer(q)
        print("\n[white on black]", out, "[/]\n")

if __name__ == "__main__":
    main()
