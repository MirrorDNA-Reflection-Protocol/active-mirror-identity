
// hmac_client.ts
import crypto from 'crypto';

export function signRequest({
  method, path, body = ''
}: { method: string; path: string; body?: string }) {
  const keyId = process.env.AMOS_KEY_ID!;
  const secret = Buffer.from(process.env.AMOS_KEY_SECRET!, 'utf8');
  const ts = Date.now().toString();
  const nonce = crypto.randomUUID();
  const bodyHash = crypto.createHash('sha256').update(body).digest('hex');
  const base = `${method}|${path}|${bodyHash}|${ts}|${nonce}`;
  const sig = crypto.createHmac('sha256', secret).update(base).digest('base64');
  return {
    'X-AMOS-Key': keyId,
    'X-AMOS-Ts': ts,
    'X-AMOS-Nonce': nonce,
    'X-AMOS-Sig': sig
  };
}
