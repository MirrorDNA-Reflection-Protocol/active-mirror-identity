
---
title: Anti‑Bot Protocol v1.0
vault_id: AMOS://Security/AntiBot/Protocol/v1.0
glyphsig: ⟡⟦TRUST⟧ · ⟡⟦SHIELD⟧ · ⟡⟦SOVEREIGNTY⟧
author: Paul Desai (Active MirrorOS)
date: 2025-10-31
status: Canonical · Governing
tags: [security, abuse-prevention, anti-bot, trust-by-design, MirrorDNA™]
---

# Anti‑Bot Protocol v1.0

**Purpose:** Stop automated abuse (signups, spam, scraping, credential stuffing) while preserving human experience and privacy.  
**Principles:** Least privilege · Layered gates · Graduated friction · Consent-first · Measurable.

---

## 0) Scope & Roles
- **Edge** (CDN/WAF): rate limits, bot heuristics, geo/ASN fencing, JA3/JA4 TLS fingerprints.
- **App** (API/Frontend): behavior scoring, PoW on demand, idempotency keys, session hygiene.
- **Data** (DB/Queues): write throttles, replay detection, abuse graph.
- **Human** (Ops): dashboards, alerts, response runbook.

---

## 1) Controls (Required)

### Edge (WAF/CDN)
- Enable bot ruleset; challenge on write paths: `/signup`, `/login`, `/reset`, `/api/*` (non-GET).
- Rate-limit tiers: per‑IP, per‑ASN, per‑country (writes only). Sliding windows: 1m/10m/1h/day.
- TLS fingerprinting (JA3/JA4) → block known automation kits.
- Turnstile/Private Access Tokens on **signup + password reset + bulk API** only.
- Geo/ASN allowlist for **/admin** and sensitive webhooks.

### App/API
- **HMAC request signing** (spec below) with `X-AMOS-Key/Nonce/Ts/Sig`; 5‑minute freshness; single‑use nonce.
- **Idempotency keys** for POST/PUT; replay → 409.
- **Progressive cooldowns** after auth/OTP failures; lockouts with email/passkey recovery.
- **PoW (adaptive)** when risk score ≥ threshold (CPU‑light puzzle; 200–500ms human cost).
- **Shadow bans**: abusive writers get 200 OK, writes sinkhole.
- **Honeypots/tar‑pits**: hidden fields + slow responses for scraper patterns.

### Data
- **Abuse graph** linking IP ↔ account ↔ device ↔ payment ↔ token; block clusters.
- **Write quotas** per entity (user, token, IP) by endpoint class.
- **JTI replay guard** on JWTs; deny reused JTIs within TTL.

---

## 2) Signals & Scoring (Behavior)
Combine:
- Header entropy, accept‑lang anomalies, headless hints.
- Pointer/keyboard cadence (client‑side, privacy‑preserving aggregates).
- TTFT outliers and request burstiness.
- Past abuse graph edges.
Action ladder: **allow → slow → JS challenge → PoW → block**.

---

## 3) User Identity & Auth
- **WebAuthn (passkeys)** first; fallback OTP/Email with verification.
- **Step‑up auth** for sensitive actions (exports, key rotates, deletes).
- **Session binding**: SameSite=strict cookies, CSRF tokens, IP/UA drift check.
- **mTLS** optional for operator CLI and private admin APIs.

---

## 4) Content & Scraping
- **Robots & allowlists** for good crawlers; signed URLs for private assets.
- **Canary links & watermarking** to detect unauthorized mirrors.
- **Tar‑pit routes** for aggressive scrapers (slowly increasing delays).

---

## 5) Webhooks & Integrations
- IP allowlists; HMAC verification; replay window ≤ 5 min.
- Enforce `User-Agent`, `X-Signature`, `X-Timestamp`; reject missing headers.

---

## 6) Observability
Dashboards to track by endpoint/ASN/country:
- 4xx/5xx rate, challenge rate, pass/fail, solve times.
- Burst alerts, credential stuffing spikes, anomaly scores.
- Weekly rule tuning with saved diffs.

---

## 7) Privacy & Trust‑by‑Design
- Prefer **Turnstile/Private Access Tokens** over invasive CAPTCHAs.
- Collect only aggregate behavior; no raw biometrics.
- Challenges only on **write/abuse** paths; reads stay smooth.
- Clear user messaging on challenges; opt‑out where feasible.

---

## 8) Runbook (Response)
1) Spike detected → confirm on dashboard (endpoint, ASN, geo).  
2) Raise friction one step (score threshold ‑0.1) → monitor 15 min.  
3) If persists → enable PoW on affected routes; add ASN fence.  
4) If targeted → deploy tar‑pits + shadow ban cluster.  
5) Post‑mortem within 24h; update rules + playbook.

---

## 9) HMAC Spec (AMOS Signed Requests)
```
Headers:
  X-AMOS-Key: <public_key_id>
  X-AMOS-Ts:  <unix_ms>
  X-AMOS-Nonce: <uuid4>
  X-AMOS-Sig: base64(HMAC_SHA256(secret, method|path|sha256(body)|ts|nonce))

Rules:
  - ts freshness ≤ 300000 ms
  - nonce single-use; store for TTL
  - mismatch → 401; replay → 409
```
Key rotation: staged (old+new valid for 24h), least privilege scopes.

---

## 10) Compliance Checks
- Quarterly red‑team of signup/login/reset.
- Monthly credential‑stuffing simulation.
- Weekly anomaly threshold review.
- Incident drill each quarter (runbook exercise).

---

**Continuity Seal**  
Version: v1.0 · Checksum: pending_vault_calculation · Status: Canonical · Governing
