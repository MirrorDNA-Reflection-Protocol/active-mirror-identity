
# Anti‑Bot Stack v1 (Active MirrorOS)

This pack includes:
- `AntiBot_Protocol_v1.0.md` — vault‑ready governing protocol.
- `cloudflare_ruleset.yaml` — baseline WAF rules.
- `nginx_anti_bot.conf` — edge rate‑limit + guards.
- `risk_scoring_template.json` — behavior scoring weights/thresholds.
- `hmac_client.ts` / `verify_hmac.ts` — signed request spec + code.

## Quick Start
1. Import protocol into Vault.
2. Apply Cloudflare rules; set `$admin_allowlist` / `$bad_ja3` lists.
3. Include NGINX snippet on `/api/`.
4. Implement HMAC verify middleware; rotate keys quarterly.
5. Tune `risk_scoring_template.json` weekly based on dashboards.

**Graduated friction ladder:** allow → slow → JS challenge → PoW → block.
