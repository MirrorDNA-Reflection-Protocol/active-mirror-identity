
// verify_hmac.ts
import crypto from 'crypto';
import type { Request, Response, NextFunction } from 'express';

const NONCE_CACHE = new Set<string>(); // replace with Redis

export function verifyHmac(req: Request, res: Response, next: NextFunction) {
  const keyId = req.header('X-AMOS-Key') || '';
  const ts = req.header('X-AMOS-Ts') || '';
  const nonce = req.header('X-AMOS-Nonce') || '';
  const sig = req.header('X-AMOS-Sig') || '';

  if (!keyId || !ts || !nonce || !sig) return res.status(401).end();
  const age = Date.now() - Number(ts);
  if (age < 0 || age > 300000) return res.status(401).end(); // 5 min

  if (NONCE_CACHE.has(nonce)) return res.status(409).end(); // replay
  // TODO: persist nonce with TTL
  NONCE_CACHE.add(nonce);

  const secret = process.env[`AMOS_SECRET_${keyId}`];
  if (!secret) return res.status(401).end();

  const bodyHash = crypto.createHash('sha256').update(req.rawBody || '').digest('hex');
  const base = `${req.method}|${req.path}|${bodyHash}|${ts}|${nonce}`;
  const expect = crypto.createHmac('sha256', secret).update(base).digest('base64');

  if (!crypto.timingSafeEqual(Buffer.from(expect), Buffer.from(sig))) {
    return res.status(401).end();
  }
  return next();
}
