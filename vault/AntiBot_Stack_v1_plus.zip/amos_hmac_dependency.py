
# amos_hmac_dependency.py
import time
import hmac
import hashlib
import base64
import os
from fastapi import Header, HTTPException, Request

NONCE_CACHE = set()  # replace with Redis
FIVE_MIN_MS = 300_000

def timing_safe_eq(a: bytes, b: bytes) -> bool:
    return hmac.compare_digest(a, b)

async def verify_hmac(
    request: Request,
    x_amos_key: str = Header(None, convert_underscores=False),
    x_amos_ts: str = Header(None, convert_underscores=False),
    x_amos_nonce: str = Header(None, convert_underscores=False),
    x_amos_sig: str = Header(None, convert_underscores=False),
):
    if request.method not in ("POST", "PUT", "PATCH", "DELETE"):
        return  # read-only methods allowed without signing by default

    if not all([x_amos_key, x_amos_ts, x_amos_nonce, x_amos_sig]):
        raise HTTPException(status_code=401, detail="missing hmac headers")

    try:
        ts_i = int(x_amos_ts)
    except ValueError:
        raise HTTPException(status_code=401, detail="bad timestamp")

    age = int(time.time() * 1000) - ts_i
    if age < 0 or age > FIVE_MIN_MS:
        raise HTTPException(status_code=401, detail="stale")

    if x_amos_nonce in NONCE_CACHE:
        raise HTTPException(status_code=409, detail="replay")
    NONCE_CACHE.add(x_amos_nonce)  # TODO: set TTL in Redis

    secret = os.getenv(f"AMOS_SECRET_{x_amos_key}")
    if not secret:
        raise HTTPException(status_code=401, detail="unknown key")

    body = await request.body()
    body_hash = hashlib.sha256(body or b"").hexdigest()
    base_str = f"{request.method}|{request.url.path}|{body_hash}|{x_amos_ts}|{x_amos_nonce}"
    expect = hmac.new(secret.encode(), base_str.encode(), hashlib.sha256).digest()
    expect_b64 = base64.b64encode(expect)

    try:
        got = base64.b64decode(x_amos_sig)
    except Exception:
        raise HTTPException(status_code=401, detail="bad signature encoding")

    if not timing_safe_eq(expect_b64, got):
        raise HTTPException(status_code=401, detail="bad signature")
