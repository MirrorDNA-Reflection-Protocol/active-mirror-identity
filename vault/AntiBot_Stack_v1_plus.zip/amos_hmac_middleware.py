
# amos_hmac_middleware.py
import time
import hmac
import hashlib
import base64
from django.http import HttpResponse

NONCE_CACHE = set()  # replace with Redis/Memcached
FIVE_MIN_MS = 300_000

def timing_safe_eq(a: bytes, b: bytes) -> bool:
    return hmac.compare_digest(a, b)

class AMOSHMACMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        # Only enforce on write methods; allow GET for read paths
        if request.method in ("POST", "PUT", "PATCH", "DELETE"):
            key_id = request.headers.get("X-AMOS-Key", "")
            ts = request.headers.get("X-AMOS-Ts", "")
            nonce = request.headers.get("X-AMOS-Nonce", "")
            sig = request.headers.get("X-AMOS-Sig", "")

            if not key_id or not ts or not nonce or not sig:
                return HttpResponse(status=401)

            try:
                ts_i = int(ts)
            except ValueError:
                return HttpResponse(status=401)

            age = int(time.time() * 1000) - ts_i
            if age < 0 or age > FIVE_MIN_MS:
                return HttpResponse(status=401)  # stale

            if nonce in NONCE_CACHE:
                return HttpResponse(status=409)  # replay
            NONCE_CACHE.add(nonce)  # TODO: expire/TTL in Redis

            secret = os.getenv(f"AMOS_SECRET_{key_id}")
            if not secret:
                return HttpResponse(status=401)

            body_bytes = request.body or b""
            body_hash = hashlib.sha256(body_bytes).hexdigest()
            base = f"{request.method}|{request.path}|{body_hash}|{ts}|{nonce}"
            expect = hmac.new(secret.encode(), base.encode(), hashlib.sha256).digest()
            expect_b64 = base64.b64encode(expect)

            try:
                got = base64.b64decode(sig)
            except Exception:
                return HttpResponse(status=401)

            if not timing_safe_eq(expect_b64, got):
                return HttpResponse(status=401)

        return self.get_response(request)
