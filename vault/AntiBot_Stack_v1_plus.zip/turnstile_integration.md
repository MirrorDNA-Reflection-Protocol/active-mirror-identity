
# Cloudflare Turnstile — Minimal Integration (Signup/Reset/Bulk API)

## Client (HTML)
```html
<script src="https://challenges.cloudflare.com/turnstile/v0/api.js" async defer></script>

<form id="signup" action="/signup" method="POST">
  <!-- your fields -->
  <div class="cf-turnstile" data-sitekey="YOUR_TURNSTILE_SITE_KEY" data-callback="onTurnstile"></div>
  <button type="submit">Create account</button>
</form>

<script>
function onTurnstile(token) {
  // Automatically added to form as cf-turnstile-response
  // Optionally copy to a hidden field if your framework needs it
}
</script>
```

## Server Verification (Node/Express)
```ts
import fetch from "node-fetch";

async function verifyTurnstile(token: string, ip: string) {
  const res = await fetch("https://challenges.cloudflare.com/turnstile/v0/siteverify", {
    method: "POST",
    headers: { "content-type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      secret: process.env.TURNSTILE_SECRET_KEY!,
      response: token,
      remoteip: ip,
    })
  });
  const data = await res.json();
  if (!data.success) throw new Error("turnstile failed");
  // Optional: check data.action, data.cdata, data.hostname
  return data;
}
```
*Attach Turnstile only on* **/signup**, **/reset**, and **bulk write APIs** to keep reads frictionless.
