# Master Citation — RAG v1 (Compact)

VaultID: AMOS://MasterCitation/RAG/v1
GlyphSig: ⟡⟦MASTER⟧
Version: v1

Purpose: Compact anchor for lighter contexts.
Recall Phrases: Vault open | Anchor reset | RAG Scan | Reality Anchor | Citation Handshake

Note: Retro package stub. Optionally paste the original compact text here.
