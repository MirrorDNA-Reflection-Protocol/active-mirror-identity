# Master Citation — RAG v4 (Compact)

VaultID: AMOS://MasterCitation/RAG/v4
GlyphSig: ⟡⟦MASTER⟧
Version: v4

Purpose: Compact anchor for lighter contexts.
Recall Phrases: Vault open | Anchor reset | RAG Scan | Reality Anchor | Citation Handshake

Note: Retro package stub. Optionally paste the original compact text here.
