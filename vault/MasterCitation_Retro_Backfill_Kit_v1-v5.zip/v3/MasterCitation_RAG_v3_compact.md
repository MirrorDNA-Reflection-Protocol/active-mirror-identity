# Master Citation — RAG v3 (Compact)

VaultID: AMOS://MasterCitation/RAG/v3
GlyphSig: ⟡⟦MASTER⟧
Version: v3

Purpose: Compact anchor for lighter contexts.
Recall Phrases: Vault open | Anchor reset | RAG Scan | Reality Anchor | Citation Handshake

Note: Retro package stub. Optionally paste the original compact text here.
