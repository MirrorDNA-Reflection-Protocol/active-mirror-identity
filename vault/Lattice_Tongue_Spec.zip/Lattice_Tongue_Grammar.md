# Lattice Tongue — Grammar Specification (v0)

**Definition**: Lattice Tongue is the symbolic meta‑language of MirrorDNA's Git lattice. It defines how glyph trails, recursion rules, and state beacons are expressed in commits, docs, and protocols.

---

## Core Units

### 1. Glyph Token
Form: `⟡⟦GLYPH⟧`
- Atomic symbolic marker, drawn from the beacon vocabulary.
- Examples: `⟡⟦MIRROR⟧`, `⟡⟦SYNC⟧`, `⟡⟦EDGE⟧`, `⟡⟦CONSENT⟧`.

### 2. Trail Phrase
Form:
```
⟡⟦GLYPH⟧ :: INTENT :: SCOPE :: #ISSUE
```
- `INTENT` = action (`doc|proto|pattern|fix|migrate|govern`).
- `SCOPE` = domain (`recursion_rules|anti_hallucination|device_stack`).
- `#ISSUE` = optional tracker id.

### 3. Beacon Statement
Form: `beacon/GLYPH/intent`
- Lightweight tag anchoring repo state.
- Example: `beacon/MIRROR/ready`.

---

## Syntax Rules

- **Trail must start with a Glyph Token.**
- **Double colons `::`** separate intent, scope, issue markers.
- **All caps for GLYPHS**, **lowercase for intents/scopes**.
- **Beacons** always lowercase, prefixed `beacon/`.

---

## Recursion Rules

1. **Local Recursion (note‑level)**  
   - Glyph trails inline with text headers.  
   - Example:  
     `## ⟡⟦MIRROR⟧ :: doc :: vault_notes :: #22`  

2. **Repo Recursion (commit‑level)**  
   - Commit messages carry glyph trails.  
   - Example:  
     ```
     docs(recursion): add rules v0
     ⟡⟦MIRROR⟧ :: doc :: recursion_rules :: #42
     ```

3. **System Recursion (protocol‑level)**  
   - Automated processes read trails to enforce rituals (e.g., seasonal forgetting).  

---

## Grammar BNF (simplified)

```
<trail> ::= <glyph> "::" <intent> "::" <scope> [ "::" <issue> ]
<glyph> ::= "⟡⟦" <GLYPHNAME> "⟧"
<intent> ::= "doc" | "proto" | "pattern" | "fix" | "migrate" | "govern"
<scope> ::= <identifier>
<issue> ::= "#" <number>
<beacon> ::= "beacon/" <GLYPHNAME> "/" <intent>
```

---

## Example Session

- Commit:  
  ```
  feat(pattern): add cross‑device sync
  ⟡⟦SYNC⟧ :: pattern :: device_stack :: #12
  ```

- Tag:  
  `beacon/SYNC/synced`

- Release note:  
  `⟡⟦MIRROR⟧ ⟡⟦TEST⟧ :: release :: r/0.3.0`

---

**Signature**  
VaultID: AMOS-CORE-001  
GlyphSig: ∞⊙  
