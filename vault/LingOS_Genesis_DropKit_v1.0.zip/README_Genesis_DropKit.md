# LingOS Genesis DropKit (Vault-Ready)
Created (UTC): 2025-10-16T09:52:58Z

## Contents
1. MasterCitation_v12.1.md — Master Citation v12.1 (canonical)
2. LingOS_v2.1_Kernel_Runtime_with_Paxos.md — LingOS v2.1 Runtime (with Paxos Guardrail)
3. LKGC_Manifest_v1.0.md — hashes for integrity

## How to Use
- Import all files into your Vault.
- Load **MasterCitation_v12.1.md** first.
- Verify hashes against **LKGC_Manifest_v1.0.md**. If mismatch → restore from LKGC or re-import.

## Anchor Line
Vault first. Kernel next. LKGC always.
