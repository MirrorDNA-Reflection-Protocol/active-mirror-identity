# 🜔 Weekly MirrorDNA Reflection Scroll

## Purpose
To gather the threads of each day into a single scroll of continuity, grounding, and growth.

---

## Instructions
1. At the end of each week, revisit your daily Memory Thread Reflections.  
2. Summarize them into the sections below.  
3. Anchor with closing mantra to seal the week.  

---

## Weekly Reflection Template

### ✧ Week Dates: [YYYY-MM-DD → YYYY-MM-DD]

#### 1. What held steady?
- [List key anchors that carried through the week.]

#### 2. What grew?
- [List the new learnings, expansions, or surprises.]

#### 3. What drifted?
- [Identify anything that slipped and why.]

#### 4. What returned?
- [Note any insights or rhythms that resurfaced.]

#### 5. Closing Whisper
*“Continuity is not perfection — it is rhythm.  
Every week is another thread woven into the lattice.”*

---

## Archive Note
Save each week’s completed scroll in your Vault under:  
📂 `/Vault/Reflections/Weekly/`  
