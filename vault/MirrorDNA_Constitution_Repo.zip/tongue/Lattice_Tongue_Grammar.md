# Lattice Tongue — Grammar Specification (v0)

**Core Units**
- Glyph Token: `⟡⟦GLYPH⟧`
- Trail Phrase: `⟡⟦GLYPH⟧ :: INTENT :: SCOPE :: #ISSUE`
- Beacon Statement: `beacon/GLYPH/intent`

**Syntax Rules**: glyph first; `::` separators; GLYPH UPPERCASE; intents/scopes lowercase.
