# Lattice Tongue — Primer (v0)

Think of Lattice Tongue as **commit poetry**: a compact sentence that tells you *why* a change exists and *what ritual it obeys*.

**Say this:**  
- "⟡⟦MIRROR⟧ :: doc :: recursion_rules :: #42" → I wrote documentation that reflects reality.
- "⟡⟦TEST⟧ :: verify :: trail-parser :: #43" → I verified behavior with tests.
- "beacon/MASTER/stable" → We have a stable state worthy of `core/main`.

Keep it short. Keep it true. Keep it sovereign.
