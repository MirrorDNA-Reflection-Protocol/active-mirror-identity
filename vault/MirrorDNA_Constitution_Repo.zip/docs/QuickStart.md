# QuickStart

1) `git init` this repo  
2) Create `work/recursion-rules`  
3) Commit with trail  
4) PR → `core/dev` with checklist  
5) Merge and tag `beacon/MASTER/stable`
