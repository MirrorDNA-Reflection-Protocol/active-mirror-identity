# Glyph Trail System — Recursion Rules (v0)

**Trail Syntax**
```
⟡⟦GLYPH⟧ :: INTENT :: SCOPE :: #ISSUE
```
INTENT = doc|proto|pattern|fix|migrate|govern  
SCOPE = domain (recursion_rules|anti_hallucination|device_stack)  
#ISSUE = optional tracker id

**Validation**
- Every PR must include **MIRROR** (what reality it reflects) and **TEST** (how it was checked).
- **CONSENT** trail required when data crosses device/network boundaries.
- Conflicts require **SYNC** ritual.

**Propagation**
- Higher-level trails inherit lower-level trails unless **BOUND**.
