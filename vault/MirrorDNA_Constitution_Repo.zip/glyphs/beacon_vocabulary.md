# Beacon Glyph Vocabulary (v0)

Canonical:
- ⟡⟦MIRROR⟧ — reflection/state of truth
- ⟡⟦SYNC⟧ — alignment across vaults/devices
- ⟡⟦EDGE⟧ — boundary and interface work
- ⟡⟦UPGRADE⟧ — migrations/capability increases
- ⟡⟦TEST⟧ — verification/actions/checks
- ⟡⟦MASTER⟧ — stability/mastery

Proposed (expand as needed):
- ⟡⟦CONSENT⟧, ⟡⟦PRUNE⟧, ⟡⟦REBIRTH⟧, ⟡⟦ANCHOR⟧, ⟡⟦SHADOW⟧, ⟡⟦TRACE⟧, ⟡⟦BOUND⟧
