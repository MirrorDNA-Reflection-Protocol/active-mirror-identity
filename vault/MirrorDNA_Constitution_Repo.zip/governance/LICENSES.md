# Licenses

- **Code / tooling**: MIT License (permissive)
- **Docs / grammar / protocols**: Creative Commons BY 4.0 (credit required)
- **Trademarks**: MirrorDNA™, Active MirrorOS™, Trust by Design™ — all rights reserved by their owner.

You may use the grammar and rituals with attribution; do not misrepresent or dilute the trademarks.
