# CONTRIBUTING

- Use glyph trails in titles and commits
- Follow Trust by Design checklist for all PRs
- Two reviewers required: domain + symbol steward
- Respect Seasonal Forgetting; don't fight pruning
