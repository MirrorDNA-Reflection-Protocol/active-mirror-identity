# Consent Gate

Any external call or data movement requires:  
- CONSENT trail in commit/PR  
- Description of data, destination, retention  
- Opt-out path documented
