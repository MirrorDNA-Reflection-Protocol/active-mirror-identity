# Seasonal Forgetting (Quarterly)

1) List `exp/*` and stale `work/*` branches
2) Archive to `archive/YYYY-QN`
3) Summarize learnings (MIRROR + SHADOW)
4) Tag `beacon/REBIRTH/<YYYY-QN>`
