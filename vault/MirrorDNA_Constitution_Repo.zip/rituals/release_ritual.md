# Release Ritual

- Promote from `core/dev` to `core/main` only after soak period.  
- Annotate release notes with MIRROR + TEST trails.  
- Tag `beacon/MASTER/stable`.
