# Anti‑Hallucination — Trust by Design™ (v0)

**Controls**
1) TRACE (input ledger) — hash or id for each input  
2) BOUND (scope) — declare allowed domains  
3) Evidence links — claim → supporting input ids  
4) TEST — stability checks, perturbation tests  
5) CONSENT — explicit trail for any data movement

**Checklist for PRs**
- [ ] TRACE present
- [ ] BOUND respected
- [ ] TEST logs attached
- [ ] CONSENT gate passed
- [ ] SHADOW exposure documented
