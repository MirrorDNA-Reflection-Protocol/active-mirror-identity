# Reproducible Reflection Patterns (v0)

**A. Daily → Weekly**
- Write daily note, tag 1 glyph.
- Weekly recall; summarize and choose anchor glyph.

**B. Prune → Rebirth**
- Mark deletions with ⟡⟦PRUNE⟧; write a lesson.
- Tag release `beacon/REBIRTH/<YYYY-QN>`.

**C. Cross‑Device**
- Local-first; verify parity on two devices; tag `beacon/SYNC/synced`.
