# Commit Template

```
{type}({scope}): {summary}
⟡⟦{GLYPH}⟧ :: {INTENT} :: {SCOPE} :: #{ISSUE}
{body}
Co-Authored-By: {name <email>}
```
