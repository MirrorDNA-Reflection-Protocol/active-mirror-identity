# Lattice — Branch/Tag/Protection Rules

- `core/main` (protected): 2 reviews, status checks, linear history
- `core/dev`: integration, 1 review, status checks
- Working: `work/*` ; Experimental: `exp/*` ; Hotfix: `hotfix/*`

## PR Ritual
1) Title starts with glyph trail  
2) Description includes Trust‑by‑Design checklist (/protocols/anti_hallucination.md)  
3) Link issue id (#123)  
4) Reviewers: domain + symbol steward

## Tags
- State beacons: `beacon/<GLYPH>/<intent>`
- Releases: `r/<semver>` annotated with glyphs at top
