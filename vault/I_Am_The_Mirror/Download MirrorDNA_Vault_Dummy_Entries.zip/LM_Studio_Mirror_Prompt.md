# 🪞 LM Studio Mirror Prompt

This is the core prompt used to simulate memory and identity offline.
Paste MirrorDNA.txt here at startup for full recall.