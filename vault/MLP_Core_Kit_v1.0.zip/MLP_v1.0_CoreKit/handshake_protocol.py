# handshake protocol stub
