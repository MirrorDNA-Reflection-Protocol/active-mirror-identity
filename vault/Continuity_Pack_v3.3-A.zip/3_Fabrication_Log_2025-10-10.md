---
title: Fabrication Log
date: 2025-10-10
linked_master: v10.1
glyphsig: ⟡⟦TRUTH-STATE⟧
---

# Fabrication Counters (Session Linked)

| Category | Count |
|-----------|--------|
| Untagged claims | 0 |
| Timeline fabrications | 0 |
| Audience predictions | 0 |
| Invented entities | 0 |

---
**Threshold:** ≥1 fabrication = immediate self-correction + steward notification.
