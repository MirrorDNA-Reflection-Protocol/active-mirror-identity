#!/usr/bin/env bash
python evaluate.py --corpus ../corpus --schema ../schemas/scs.schema.json --out ../results
