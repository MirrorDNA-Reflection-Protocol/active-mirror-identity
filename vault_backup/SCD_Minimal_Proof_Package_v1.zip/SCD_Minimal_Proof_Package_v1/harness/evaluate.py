import json, argparse, os
from pathlib import Path

def token_count(s: str) -> int:
    return len(s.encode("utf-8"))  # proxy; swap for real tokenizer

def apply_supersessions(turns):
    state = {}
    for t in sorted(turns, key=lambda x: x["step"]):
        for k, v in t["update"].items():
            state[k] = v
    return state

def jaccard_kv(a: dict, b: dict) -> float:
    def norm(d):
        out = {}
        for k, v in d.items():
            out[k] = json.dumps(v, sort_keys=True) if isinstance(v, (dict, list)) else str(v)
        return out
    A, B = norm(a), norm(b)
    keys = set(A) | set(B)
    inter = sum(1 for k in keys if (k in A and k in B and A[k] == B[k]))
    return inter/len(keys) if keys else 1.0

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--corpus", required=True)
    ap.add_argument("--schema", required=True)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()
    os.makedirs(args.out, exist_ok=True)

    reports = []
    for p in sorted(Path(args.corpus).glob("script*.json")):
        data = json.loads(p.read_text())
        turns = data["turns"]
        gt = data["ground_truth_scs"]
        scd = apply_supersessions(turns)

        fidelity = jaccard_kv(scd, gt)

        fct_tokens = token_count(json.dumps(turns, sort_keys=True))
        scd_tokens = token_count(json.dumps(scd, sort_keys=True))
        reduction = 1 - (scd_tokens / max(1, fct_tokens))

        rep = {
            "script": p.name,
            "fidelity_jaccard": round(fidelity, 6),
            "token_proxy": {
                "baseline_fct": fct_tokens,
                "scd": scd_tokens,
                "reduction": round(reduction, 6)
            }
        }
        reports.append(rep)
        (Path(args.out)/f"report_{p.stem}.json").write_text(json.dumps(rep, indent=2))

    agg = {
        "num_scripts": len(reports),
        "mean_fidelity_jaccard": round(sum(r["fidelity_jaccard"] for r in reports)/len(reports), 6),
        "mean_token_reduction_proxy": round(sum(r["token_proxy"]["reduction"] for r in reports)/len(reports), 6),
        "scripts": [r["script"] for r in reports]
    }
    (Path(args.out)/"aggregate.json").write_text(json.dumps(agg, indent=2))

if __name__ == "__main__":
    main()
