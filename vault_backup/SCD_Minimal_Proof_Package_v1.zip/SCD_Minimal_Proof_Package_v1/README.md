# SCD Minimal Proof Package (v1)

Validate the principle behind **Structured Contextual Distillation (SCD)**:
- **>80% token reduction** vs. full-context prompting
- **High fidelity** to the final state using structured, superseding updates

## Quickstart
```bash
cd SCD_Minimal_Proof_Package_v1/harness
pip install -r requirements.txt
python evaluate.py --corpus ../corpus --schema ../schemas/scs.schema.json --out ../results
```
The harness is API-free. Swap the token proxy with a real tokenizer to reproduce production counts.
