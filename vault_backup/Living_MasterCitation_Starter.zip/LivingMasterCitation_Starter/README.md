# Living MasterCitation — Starter

This starter includes:
- `Living MasterCitation.md` — your living nucleus
- `templates/Artifact_Template.md` — drop‑in template for new artifacts

**QuickStart**
1) Import both files into your Obsidian Vault under `/Vault/MasterCitation/`.
2) Open `Living MasterCitation.md` and keep it pinned.
3) For any new paper, duplicate `templates/Artifact_Template.md` and fill section by section.
4) When sections are done, issue the merge cue (manually or via agent prompt).

Created: 2025-10-11 08:30:11 IST
