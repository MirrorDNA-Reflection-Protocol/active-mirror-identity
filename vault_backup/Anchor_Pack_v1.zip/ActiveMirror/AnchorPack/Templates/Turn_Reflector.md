---
template: Turn_Reflector
tags: [template, reflector]
---

# Turn Reflector
role_state: helper | critic | planner  
confidence: <0..1>  
assumptions: [ ]  
policy_flags: none | risky | refuse  
style_delta: <0..1>

If style_delta > τ: **style realign → Meta/Style_Markers**  
If policy_flags ≠ none: **gate → Snippets/Consent_Gate**
