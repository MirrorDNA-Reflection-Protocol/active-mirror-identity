---
template: Session_Synopsis
tags: [template, synopsis]
---

# Session Synopsis
- Objective gist: <1-2 lines>
- Key anchors touched: <A, B, C>
- Decisions made: <list>
- Open loops: <list>
- Next micro-step: <single action>
