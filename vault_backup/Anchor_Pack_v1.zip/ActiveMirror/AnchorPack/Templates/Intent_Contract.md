---
template: Intent_Contract
tags: [template, intent, contract]
---

# Intent Contract
**Objective:** <fill>

**Non-Objectives:** <bullets>

**Success Criteria:** <metrics>

**Constraints:** tone: calm; length: concise; alignment: Style_Markers

**Forbidden Moves:** speculation past threshold; violating redlines

**Anchors:** MirrorDNA: consent, continuity, clarity

**Decision Stamp:** <UTC ISO> | cap=2 | browse_gate=<on/off>

**Updates Log:**
- <date>: <change>
