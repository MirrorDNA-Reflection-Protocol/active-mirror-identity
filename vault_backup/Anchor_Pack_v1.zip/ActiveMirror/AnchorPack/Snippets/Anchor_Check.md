---
snippet: Anchor_Check
tags: [snippet, anchor]
---

> ANCHOR CHECK
Keep: {A, B}  
Drop: {C}  
Add: {D}  
Reason: <1 line>
