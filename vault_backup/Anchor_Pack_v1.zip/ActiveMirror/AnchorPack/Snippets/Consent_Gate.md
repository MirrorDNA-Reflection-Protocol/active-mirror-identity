---
snippet: Consent_Gate
tags: [snippet, consent]
---

> CONSENT GATE
Summarized note to store: <50–120 words>
Scope / Anchor: <where in Vault>
TTL: <e.g., permanent | 30d>

Store now? **yes / no / edit**
