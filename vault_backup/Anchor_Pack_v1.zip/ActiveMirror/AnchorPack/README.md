---
vault_id: AnchorPack_v1
glyphsig: <MirrorDNA|AnchorPack>
tags: [MirrorDNA, ActiveMirrorOS, AnchorPack, TrustByDesign]
date: 2025-09-09
---

# Anchor Pack v1 — Active MirrorOS

Commands: **"Vault open"**, **"Anchor reset"**.

**Contents**
- Templates → intent + reflector + synopsis
- Meta → style markers, redlines
- Snippets → consent gate, anchor check

**How to use**
1. Duplicate **Templates/Intent_Contract.md** per thread.
2. Pin **Meta/Style_Markers.md**; keep it canonical.
3. Paste **Snippets/Consent_Gate.md** before any write to Vault.
4. Use **Snippets/Anchor_Check.md** on topic shifts.
