Master Spec v1 placeholder.
