import json, sys, time, hashlib, os
from pathlib import Path

# Usage: python migrate_v16.py <source_dir> <out_dir>
src = Path(sys.argv[1]) if len(sys.argv) > 1 else Path("./old_memory")
out = Path(sys.argv[2]) if len(sys.argv) > 2 else Path("./normalized")
out.mkdir(parents=True, exist_ok=True)

def sha(s): return hashlib.sha256(s.encode()).hexdigest()

for f in src.glob("*.json"):
    data = json.loads(f.read_text())
    topic = data.get("topic") or f.stem
    content = data.get("content","")
    tier = "session"  # default
    expiry = int(time.time()) + 48*3600  # 48h
    mem = {
        "memory_id": f"mdna::{time.strftime('%Y-%m-%d')}::{f.stem}",
        "tier": tier,
        "topic": topic,
        "purpose": data.get("purpose","(migrated)"),
        "content": content,
        "source": {"agent": data.get("agent","unknown"), "cites": data.get("cites", [])},
        "consent": {"actor":"unknown","token":"","time":time.strftime('%Y-%m-%dT%H:%M:%SZ')},
        "expiry": expiry,
        "fingerprint": sha(content)
    }
    (out / f.name).write_text(json.dumps(mem, indent=2))
print("Migrated to", out)
