# MirrorDNA Memory Pack v1 — 2025-08-14

Contents
- schema.yaml — canonical memory shape (atomic + mergeable)
- router_rules.yaml — promotion/denial logic + authority order
- prompts/write.txt, prompts/recall.txt — drop-in agent prompts
- scripts/migrate_v16.py — normalize older items into schema

Install
1) Put this folder in `/memory/` of DropKit.
2) Ensure all agents use the same prompts for write/recall.
3) Nightly job: purge expired Session items; prompt to promote high-usage items.
