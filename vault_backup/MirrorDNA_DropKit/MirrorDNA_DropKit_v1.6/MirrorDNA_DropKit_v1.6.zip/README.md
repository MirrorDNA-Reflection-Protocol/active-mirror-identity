# MirrorDNA DropKit v1

This kit includes:
- **docs/**: core protocols & blueprints (LSA Loop, Deep Agent, Full-Life Unlock).
- **policies/**: safety stack (UGS-v1) + Physics & Chirality protocols.
- **profiles/**: example user profiles (e.g., Mom kidney-safe v2/v3).
- **modules/**: LAG×GEPA reasoning/adaptation module.
- **prompts/**: ready-to-use prompt files.
- **cards/**: vault cards (Claude Memory, Confidence Loop).

## Install
1) Copy `policies/UGS_bundle_v1/guardrails` into your repo and verify `policy_bundle.signature.json` hash matches `mirrorDNA.root.yaml`.
2) Import `docs/*.md` and `cards/*.md` into your Obsidian vault or MirrorOS.
3) Select a profile from `profiles/` at init (e.g., elder + kidney_safe).

## CI Gate (optional)
Fail CI if the policy bundle hash changes without approval.

