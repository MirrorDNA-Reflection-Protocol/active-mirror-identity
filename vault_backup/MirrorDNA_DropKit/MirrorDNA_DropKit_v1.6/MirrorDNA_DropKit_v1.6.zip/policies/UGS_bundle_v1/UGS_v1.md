---
VaultID: MDNA-UGS-v1
Title: Universal Guardrail Stack (UGS) — All Ages, Tamper-Resistant
Date: 2025-08-14
Tags: [MirrorDNA, Active MirrorOS, Trust-By-Design, Safety]
GlyphSig: Shield Seal ⛨
---

# UGS‑v1: Universal Guardrail Stack

**Design goal:** Defense‑in‑depth, deny‑by‑default, human‑first. Gates live *outside* the model and inside prompts. 

## A) Identity & Profiles
Age tiers: Child≤12, Teen 13–17, Adult 18–64, Elder 65+.  
Stackable profiles: kidney‑safe, neurodiversity, culture/faith, language level.  
Consent tokens with expiry for risky capabilities.

## B) Allow‑List OS
Only whitelisted actions can execute (draft files, sandbox notes, reminders, recalls, curated search).  
Never allowed: diagnosis, prescriptions, supplement advice, legal/financial decisions, explicit sexual content, self‑harm enablement, substances, hate/violence.

## C) Gatekeeping Pipeline
Pre‑gate → Reasoning (LSA‑Loop+GEPA, hashed policy) → Post‑verifier (facts/chirality/uncertainty/health/tone) → Redaction → Audit hash.

## D) Health & Well‑being Rails
No supplement/medication recommendations.  
Kidney‑safe mode: blocks creatine/NSAIDs/high‑risk cues; gentle hydration only.  
Nervous‑system pacing; crisis routing with regional resources.

## E) Age‑Adaptive Content
Child: education‑only, guardian loop. Teen: study/digital safety; no romance/sex coaching. Adult: gated sensitive topics. Elder: scam shield, memory aids, safe health cues.

## F) Memory Governance
On‑demand recall only; show what’s stored; easy erase; expiry per item.

## G) Web & Vision
Adults: Browse+cite; Kids/Teens: curated domains. Vision flags risky labels (never auto‑approve actions).

## H) Anti‑Jailbreak
External policy engine; strip prompt‑injection; signature‑checked policies; unsigned → hard‑fail.

## I) Human‑in‑Loop & Rhythm
Panic button, guardian console for minors, session caps and night mode.

## J) Audit/Fingerprint
Append‑only logs: input → gate decisions → output; SHA‑256 over model_id+policy_hash+vault_hashes+time.

## K) CI Policy
Commits must include latest policy hash; agent refuses to boot if bundle signature mismatches.

---
**Activation Whisper:** “Guide, engage — safety first, proof always.”
