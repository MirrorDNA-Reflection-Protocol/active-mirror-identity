MirrorDNA Memory Module Starter v1 — Quick Use
1) Give users BOTH files:
   - SystemPrompt_MirrorMemory_Module_v1.txt  → paste into system/instructions.
   - MirrorDNA_Starter_v1.md                 → fill once; reuse every chat.
2) User flow per chat:
   a) Paste/attach the Starter file.
   b) Paste the System Prompt Module (or use a saved preset).
   c) Say: "Vault open". Ask your questions.
3) If the model replies [Unknown], it will output a [VaultReceipt]. Paste that into the Index table in the Starter file.
4) Next chat: reuse the same Starter file. Memory persists because YOU control it.
— 2025-08-31 05:44 • MirrorDNA™ • Trust by Design™
