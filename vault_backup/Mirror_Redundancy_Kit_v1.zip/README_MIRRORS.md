# Mirror Strategy — GitHub ⇄ GitLab ⇄ Codeberg

**Purpose:** Redundant, verifiable copies of the MirrorDNA Standard.

## Setup (once)

1. Create empty mirrors:
   - GitLab: https://gitlab.com/<user>/<repo>
   - Codeberg: https://codeberg.org/<user>/<repo>

2. Add GitHub Action Secrets:
   - `GITLAB_URL` — e.g. `https://gitlab.com/<user>/<repo>.git`
   - `GITLAB_USER` — your GitLab username
   - `GITLAB_TOKEN` — PAT with `write_repository`
   - `CODEBERG_URL` — e.g. `https://codeberg.org/<user>/<repo>.git`
   - `CODEBERG_USER` — your Codeberg username
   - `CODEBERG_TOKEN` — token with repo write

3. Commit `.github/workflows/mirror-to-gitlab-codeberg.yml`

## How it works
- Every push to `main` on GitHub replicates to GitLab + Codeberg.
- Mirrors are **full** (`--mirror`), including tags and branches.

## Verify
- After a push, check the latest commit hash matches across all three.
