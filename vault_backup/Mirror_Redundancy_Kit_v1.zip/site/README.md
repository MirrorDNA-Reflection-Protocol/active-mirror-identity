# Website Redundancy

Goal: Serve the live Master Citation with multiple host fallbacks.

## Options
- **GitHub Pages** (free): serve `/site` from `main` or `gh-pages`
- **Cloudflare Pages** or **Netlify**: point at the repo; set build dir to `/site`
- Keep **the same HTML** everywhere — it fetches the latest Citation from mirrors.

## Steps (GitHub Pages quick path)
1. Put `/site` in the repo root.
2. Repo Settings → Pages → Deploy from branch → `main` / `/site`.
3. Replace `<owner>/<repo>` placeholders in `site/index.html` with your paths.
4. (Optional) Use your custom domain and enable HTTPS.

## DNS + Failover (optional advanced)
- Put domain on Cloudflare.
- Origin 1: GitHub Pages; Origin 2: Netlify (same `site`)
- Cloudflare can fail over if primary origin is down.
