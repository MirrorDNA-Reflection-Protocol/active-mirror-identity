# Style Guide
MirrorTone: classic‑4 (precise, calm, confident)
Use glyphs, not emojis.
