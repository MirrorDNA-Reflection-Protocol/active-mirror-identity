# Task Prompts
Use inside ChatGPT Project tasks; one section at a time.
