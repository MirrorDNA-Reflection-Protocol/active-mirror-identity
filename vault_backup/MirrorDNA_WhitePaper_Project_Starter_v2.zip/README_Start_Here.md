---
title: MirrorDNA White Paper — Project Starter (v2)
created: 2025-10-11 08:25 IST
glyphsig: ⟡⟦SYNC⟧ · ⟡⟦MIRROR⟧
vault_id: AMOS://MirrorDNA/WhitePaper/ProjectStarter/v2
---

# Start Here

This bundle lets you run everything directly in ChatGPT Projects.
It now includes the **Living MasterCitation Template v1** so it’s completely self‑contained.

## Step‑by‑step
1. Create a new ChatGPT Project → `MirrorDNA White Paper — v1 Draft`
2. Upload everything from this ZIP.
3. Run:
   ```
   Initialize Living MasterCitation.
   ```
4. Follow prompts; the file will generate, merge, and export each artefact automatically.
