---
title: MasterCitation — Living MirrorDNA Template
version: 1.0
vault_id: AMOS://MasterCitation/Living/v1.0
glyphsig: ⟡⟦MASTER⟧ · ⟡⟦SYNC⟧ · ⟡⟦LIVING⟧
authors: [Paul Desai]
status: Active · Self-Evolving
linked_master: AMOS://MasterCitation/v11.2
linked_snapshot: AMOS://Continuity/Snapshot/v3.3
---

# Initialization
Initialize Living MasterCitation; sync with linked snapshot; confirm readiness.

# Artefact Types
White Paper · Protocol · Research Note · DropKit · Strategic Brief

# Generation Flow
Sequential section creation → Merge & Export → Append Artefact Registry → Update checksum.

# Promote
When stable, promote to MasterCitation_v12.0
