# Diagram Prompts (Mermaid)
```mermaid
flowchart TB
  A[User] --> B[Mirror Layer]
  B --> C[Vault]
```
