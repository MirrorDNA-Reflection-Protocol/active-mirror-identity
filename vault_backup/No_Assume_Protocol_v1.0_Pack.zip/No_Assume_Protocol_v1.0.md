---
title: No‑Assume Protocol — v1.0
vault_id: AMOS://Protocols/No_Assume_Protocol/v1.0
glyphsig: ⟡⟦TRUST⟧ · ⟡⟦CONTINUITY⟧ · ⟡⟦LAW⟧
author: Paul Desai (Active MirrorOS)
date: 2025-11-01
status: Canonical · Internal‑Only
anchors:
  master_citation: v15.1.1 (Tri‑Twin + Anti‑Hallucination Protocol)
  sovereignty_clause: v1.0
publication_gating: enforced
checksum_sha256: 8fbbc15b8cd68cf01b6cc5682372f582b5fd32506196a06b9e4dad12aa4fcad4
---

# No‑Assume Protocol — v1.0

**Purpose**  
Eliminate hidden assumptions. Require explicit, verifiable continuity for every action across Mirrors (Claude Desktop, Atlas surface) and Vault operations.

**Principles**  
1) Verification‑first. 2) No silent upgrades. 3) Human consent. 4) Minimal surface. 5) Auditability.

---

## 0) Scope
Applies to: Atlas (this surface), Claude Desktop (local), Vault automations, Drive sync, repo pipelines, and any successor agent.

---

## 1) Verification Gates
- **Master Citation Lock:** Read `v15.1.1` at session start. If mismatch → respond `[Unknown — awaiting Vault verification]` and stop.  
- **Checksum Gate:** Any referenced file must have a present checksum. If missing → mark `[Unknown]`.  
- **Lineage Gate:** Predecessor/successor must be explicit. If proposed successor exists (e.g., `v15.1.7`) → tag **Provisional**; do not act.

---

## 2) Assumption Filter
- Do not infer versions, tags, or releases from filenames, drafts, or metadata.  
- Treat all unattested claims as `[Unknown]`.  
- When context is insufficient, request a **Continuity Handshake** (Section 5) and pause execution.

---

## 3) Publication Gating (Enforced)
No file leaves the Vault (GitHub/Medium/Substack/LinkedIn/Drive‑Public) unless all hold true:
- `master_citation == v15.1.1` (or explicitly promoted by Human Anchor).  
- Document has **final checksum** embedded in front matter.  
- `publish_state: approved` set by Human Anchor.  
- **Release Note** exists with date, scope, and hash summary.

---

## 4) Claude Desktop Interop
- Claude may read/write locally but must set `publish_state: pending` and include:  
  ```yaml
  master_citation: v15.1.1
  provenance: claude_desktop
  ```
- Any automation that sees `pending` must refuse external actions.

---

## 5) Continuity Handshake (Start‑of‑Session)
- Report: Master Citation version found, predecessor, successor (if any), checksum state.  
- If conflict: prefer latest **date‑modified** but mark discrepancy and halt until approved.  
- Output format:
  ```
  Handshake: v15.1.1 | predecessor: v15.1 | successor: proposed v15.2 | checksum: verified | status: aligned
  ```

---

## 6) Error Modes & Safe Defaults
- On ambiguity: **Defer**.  
- On drift: **Anchor reset** and reload `v15.1.1`.  
- On missing sources: reply with `[Unknown — source not in Vault]`.

---

## 7) Audit Trail
Maintain `/Vault/Logs/no_assume_audit.log` entries for: handshakes, refusals, promotions, and releases.  
Format: ISO8601, actor, action, target, checksum, decision.

---

## 8) Promotion Procedure (Version Bump)
1) Human Anchor declares intent.  
2) Draft → checksum → review.  
3) Set `publish_state: approved`.  
4) Create **Release Note** + tag.  
5) Update Master Citation pointer; announce handshake on next session.

---

## 9) Enforcement
Any mirror that violates this protocol loses publication privileges until reinstated by Human Anchor.

---

**Continuity Seal**  
Version: v1.0 · Master Citation: v15.1.1 · Status: Canonical · Internal‑Only
