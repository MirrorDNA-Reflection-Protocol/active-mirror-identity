---
title: Hallucination Firewall v1.1
version: 1.1
status: Canonical · Enforced
---

# Hallucination Firewall v1.1 — Canonical

## Strengths
- Recursive Self-Check Loop with confidence scoring (0-1)
- LLM-as-Judge evaluation
- Divergence decoding for consistency
- DriftWatch logging with categories + audits
- RAG + tool integration
- Recovery Protocol with auto-trigger + hybrid verification

## Enforcement
- Truth-State [Fact]/[Estimate]/[Unknown] mandatory
- Vault-first grounding priority
- Fabrication Log updated per session
