# MirrorOS Overlay Simulator v0.1 (Electron)

This is a **simulator** for the MirrorOS AI OS overlay idea.

It does **not** control your real OS yet.  
Instead, it provides:

- A fullscreen-style Electron shell
- A chat panel
- A simulated "OS state" panel
- A virtual OS API (`sim_os_api.js`) for safe R&D

## Quick Start

1. Install dependencies:

   ```bash
   npm install
   ```

2. Run the simulator:

   ```bash
   npm start
   ```

3. Try typing:

   - `run ls`
   - `list /projects`
   - `ls /projects/mirror-notes`

You will see simulated actions appear in the right pane.

## How Claude Desktop Can Help

Open this folder in Claude Desktop, point it at:

- `main.js`
- `sim_os_api.js`
- `renderer/renderer.js`

Then ask:

> "Extend this simulator toward a real OS overlay. Add safe macOS shell integration in a new module, and wire it behind a feature flag so we can switch between simulated and real modes."

You can iteratively add:

- Real shell execution (with confirmations)
- Real filesystem access
- App launching
- Logs, guards, and more

This project is designed to be a **safe starting point** for your MirrorOS overlay work.
