/**
 * MirrorOS Overlay Simulator v0.1
 * Electron main process
 */

const { app, BrowserWindow, ipcMain } = require('electron');
const path = require('path');
const os = require('os');
const { simulateCommand, simulateFileOp, getSimulatedState } = require('./sim_os_api');

let mainWindow;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1400,
    height: 900,
    minWidth: 1100,
    minHeight: 700,
    backgroundColor: '#050510',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      nodeIntegration: false,
      contextIsolation: true
    }
  });

  mainWindow.loadFile(path.join(__dirname, 'renderer', 'index.html'));

  // Optional: uncomment for dev tools
  // mainWindow.webContents.openDevTools();

  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}

app.whenReady().then(() => {
  createWindow();

  app.on('activate', function () {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  // Standard macOS behavior
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

/**
 * IPC: handle simulated OS actions.
 * This is where Claude / the LLM "hands" will eventually talk.
 */

ipcMain.handle('mirroros:getState', async () => {
  return getSimulatedState();
});

ipcMain.handle('mirroros:runCommand', async (_event, command) => {
  // In v0.1 we simulate. In the future this can call real shell commands with safety checks.
  return simulateCommand(command);
});

ipcMain.handle('mirroros:fileOp', async (_event, op) => {
  return simulateFileOp(op);
});
