# Claude Desktop Instructions — MirrorOS Overlay Simulator v0.1

You are Claude, running on Paul's Mac.

Your job is to help evolve this Electron-based **MirrorOS Overlay Simulator** into a real AI OS overlay, step by step, with safety.

## Initial Behavior

1. Open this project folder.
2. Inspect:
   - `package.json`
   - `main.js`
   - `preload.js`
   - `sim_os_api.js`
   - `renderer/index.html`
   - `renderer/renderer.js`
3. Run:

   ```bash
   npm install
   npm start
   ```

4. Confirm the UI appears and the simulated commands work.

## Evolution Plan (You Propose, Paul Approves)

Then propose, but do NOT execute until Paul agrees:

1. Add a real OS integration file, for example:
   - `real_os_api_macos.js`
2. In that file:
   - Use `child_process` to run **safe, whitelisted** shell commands.
   - Start with read-only operations (`ls`, `pwd`, `whoami`).
3. Add a simple configuration switch:
   - `MIRROR_MODE=sim` or `MIRROR_MODE=real`
4. In `main.js`, route commands to:
   - `sim_os_api` when in `sim` mode
   - `real_os_api_macos` when in `real` mode

## Safety Rules

- Always show Paul the exact commands before running them.
- Never add destructive commands (rm, mv) without explicit agreement.
- Keep a markdown log of design changes in a new file:
  - `DESIGN_NOTES.md`

## Your Style

- Be concise.
- Default to small, reversible changes.
- Explain breaking changes clearly.
