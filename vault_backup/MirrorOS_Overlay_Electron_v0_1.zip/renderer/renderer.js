/**
 * Renderer logic for MirrorOS Overlay Simulator v0.1
 * Simple chat -> simulated OS state/actions pipeline.
 */

const chatLog = document.getElementById('chat-log');
const actionsLog = document.getElementById('actions-log');
const chatForm = document.getElementById('chat-form');
const chatInput = document.getElementById('chat-input');
const statusText = document.getElementById('status-text');

function appendChat(sender, text) {
  const div = document.createElement('div');
  div.className = `chat-entry ${sender}`;
  div.innerHTML = `
    <div class="label">${sender === 'user' ? 'You' : 'Overlay'}</div>
    <div class="message">${text}</div>
  `;
  chatLog.appendChild(div);
  chatLog.scrollTop = chatLog.scrollHeight;
}

function appendAction(entry) {
  const div = document.createElement('div');
  div.className = 'action-entry';
  div.innerHTML = `
    <div class="meta">
      <span>${entry.type}</span>
      <span>${entry.at}</span>
    </div>
    <div class="body">${entry.detail}</div>
  `;
  actionsLog.appendChild(div);
  actionsLog.scrollTop = actionsLog.scrollHeight;
}

async function refreshState() {
  try {
    const state = await window.mirrorOS.getState();
    actionsLog.innerHTML = '';
    (state.recentActions || []).forEach(appendAction);
    statusText.textContent = `Simulating on ${state.system.platform} (${state.system.arch})`;
  } catch (err) {
    console.error(err);
    statusText.textContent = 'Error fetching state';
  }
}

chatForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  const text = chatInput.value.trim();
  if (!text) return;

  appendChat('user', text);
  chatInput.value = '';

  // Naive intent parsing for v0.1
  statusText.textContent = 'Thinking (simulated)...';

  if (text.startsWith('run ')) {
    const cmd = text.slice(4);
    const res = await window.mirrorOS.runCommand(cmd);
    const msg = res.ok ? res.output : `Error: ${res.error || 'unknown'}`;
    appendChat('system', msg);
  } else if (text.startsWith('ls ') || text.startsWith('list ')) {
    const path = text.replace(/^ls\s+|^list\s+/, '');
    const res = await window.mirrorOS.fileOp({ action: 'list', path });
    if (res.ok) {
      appendChat('system', `Entries at ${path}:\n- ${res.entries.join('\n- ')}`);
    } else {
      appendChat('system', `Error: ${res.error}`);
    }
  } else {
    appendChat('system', 'Simulated overlay: I received your instruction. In v0.1, try:
- run ls
- list /projects
- ls /projects/mirror-notes');
  }

  await refreshState();
  statusText.textContent = 'Idle';
});

// Initial load
refreshState();
