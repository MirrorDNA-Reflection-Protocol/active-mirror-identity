/**
 * sim_os_api.js
 * MirrorOS Overlay Simulator v0.1
 *
 * This module simulates OS-level actions (commands, file operations)
 * so you can develop and test the AI shell without touching the real OS.
 *
 * Later, this can be swapped or extended with real implementations.
 */

const path = require('path');

const simulatedState = {
  system: {
    platform: process.platform,
    arch: process.arch,
    homedir: require('os').homedir()
  },
  recentActions: [],
  virtualFS: {
    '/projects': ['mirror-notes', 'trading-journal'],
    '/projects/mirror-notes': ['README.md', 'notes.md'],
    '/projects/trading-journal': ['README.md', 'journal.md']
  }
};

function pushAction(type, detail) {
  simulatedState.recentActions.unshift({
    type,
    detail,
    at: new Date().toISOString()
  });
  simulatedState.recentActions = simulatedState.recentActions.slice(0, 20);
}

function getSimulatedState() {
  return simulatedState;
}

async function simulateCommand(command) {
  // Super-simple simulation
  const trimmed = String(command || '').trim();
  if (!trimmed) {
    return { ok: false, output: 'No command provided.' };
  }

  pushAction('command', trimmed);

  if (trimmed === 'ls' || trimmed === 'pwd') {
    return {
      ok: true,
      output: `Simulated shell: ${trimmed} (no real OS interaction yet)`
    };
  }

  return {
    ok: true,
    output: `Simulated execution: "${trimmed}" (no real OS interaction yet)`
  };
}

async function simulateFileOp(op) {
  /**
   * op = {
   *   action: 'list' | 'read' | 'write' | 'delete',
   *   path: '/projects/mirror-notes',
   *   content?: string
   * }
   */
  const action = op?.action;
  const targetPath = op?.path;

  if (!action || !targetPath) {
    return { ok: false, error: 'Missing action or path.' };
  }

  const normalized = path.posix.normalize(targetPath);
  const vfs = simulatedState.virtualFS;

  if (action === 'list') {
    if (!vfs[normalized]) {
      return { ok: false, error: `Path not found in virtual FS: ${normalized}` };
    }
    pushAction('file:list', normalized);
    return { ok: true, entries: vfs[normalized] };
  }

  if (action === 'read') {
    pushAction('file:read', normalized);
    return {
      ok: true,
      content: `Simulated content of ${normalized}. In v0.1 this is just a placeholder.`
    };
  }

  if (action === 'write') {
    const content = op.content || '';
    pushAction('file:write', normalized);
    vfs[normalized] = vfs[normalized] || [];
    return {
      ok: true,
      message: `Simulated write to ${normalized}. Content length: ${content.length}`
    };
  }

  if (action === 'delete') {
    pushAction('file:delete', normalized);
    delete vfs[normalized];
    return { ok: true, message: `Simulated delete of ${normalized}` };
  }

  return { ok: false, error: `Unknown file action: ${action}` };
}

module.exports = {
  getSimulatedState,
  simulateCommand,
  simulateFileOp
};
