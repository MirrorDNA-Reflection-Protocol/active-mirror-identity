/**
 * MirrorOS Overlay Simulator v0.1
 * Preload: safely expose limited API to renderer.
 */

const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('mirrorOS', {
  getState: () => ipcRenderer.invoke('mirroros:getState'),
  runCommand: (command) => ipcRenderer.invoke('mirroros:runCommand', command),
  fileOp: (op) => ipcRenderer.invoke('mirroros:fileOp', op)
});
