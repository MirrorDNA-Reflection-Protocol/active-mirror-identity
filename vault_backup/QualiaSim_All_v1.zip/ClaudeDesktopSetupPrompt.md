# Claude Desktop Setup Prompt
Paste this into Claude Desktop:
(…instructions…)