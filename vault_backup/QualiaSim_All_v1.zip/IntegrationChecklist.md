# Integration Checklist
- Drop in files
- Update LocalAgent
- Test update loop
