# QualiaSim README
(…starter + integration notes…)