# qualiasim_core.py
(…python module content…)