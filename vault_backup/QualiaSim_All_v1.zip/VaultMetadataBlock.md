# Vault Metadata Block
vault_id: AMOS://QualiaSim/v1
glyphsig: ⟡⟦QUALIA⟧
