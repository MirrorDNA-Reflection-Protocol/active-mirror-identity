# Source Registry — Active MirrorOS White Paper v7.0
- MasterCitation v11.2 (AMOS://MasterCitation/v11.2)
- Continuity Snapshot v3.2 (AMOS://Continuity/Snapshot/2025-10-09)
- DreamSeed v10.0 (AMOS://ActiveMirrorOS/FutureVault/DreamSeed)
- Project_Tasks_List.txt
- agent_merge_prompt.txt
