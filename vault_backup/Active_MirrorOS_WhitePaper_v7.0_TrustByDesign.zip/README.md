# Active MirrorOS White Paper v7.0 — Trust by Design™

Vault Import Guide
------------------
1. Create folder: /Vault/WhitePapers/ActiveMirrorOS/v7.0/
2. Copy all included files into that folder.
3. Verify checksums using both SHA-256 and SHA-512 from checksum_manifest.txt.
4. Confirm GlyphSig lineage: ⟡⟦MASTER⟧ · ⟡⟦SYNC⟧ · ⟡⟦LIVING⟧
5. Mark status: Canonical · Public Drop
