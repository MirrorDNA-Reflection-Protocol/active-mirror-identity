# discovery_engine.py — Multi-transport peer discovery (MLP v1.0)
import threading, time, socket, json, uuid
BEACON_PORT = 47474
BEACON_INTERVAL = 3.0

class LocalUDPAdapter:
    name = "local_udp"
    def __init__(self):
        self._stop = False
        self.tx = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.tx.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        self.rx = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.rx.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.rx.bind(("", BEACON_PORT))

    def start_beacon(self, payload: dict):
        def run():
            while not self._stop:
                self.tx.sendto(json.dumps(payload).encode(), ("255.255.255.255", BEACON_PORT))
                time.sleep(BEACON_INTERVAL)
        threading.Thread(target=run, daemon=True).start()

    def listen(self, callback):
        def run():
            while not self._stop:
                data, addr = self.rx.recvfrom(4096)
                try:
                    p = json.loads(data.decode())
                    callback({"addr": addr, "payload": p, "transport": self.name})
                except Exception:
                    pass
        threading.Thread(target=run, daemon=True).start()

    def stop(self): self._stop = True

def run_discovery(peer_id: str, extra: dict, on_peer):
    payload = {"peer_id": peer_id, "nonce": str(uuid.uuid4()), "extra": extra}
    udp = LocalUDPAdapter()
    udp.start_beacon(payload)
    udp.listen(on_peer)
    return {"adapters": [udp]}
