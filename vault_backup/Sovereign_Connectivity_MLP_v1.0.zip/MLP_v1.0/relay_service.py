# relay_service.py — Consent-bound store-and-forward (MLP v1.0)
import os, json, time, hashlib

MAILBOX = "relay_mailboxes"
os.makedirs(MAILBOX, exist_ok=True)

def put(dest_peer: str, payload: bytes, permit: dict):
    if permit.get("bytes_cap", 10_000_000) < len(payload):
        raise ValueError("permit bytes_cap exceeded")
    rec = {"ts": time.time(), "sha256": hashlib.sha256(payload).hexdigest(),
           "permit": permit, "payload_hex": payload.hex()}
    with open(os.path.join(MAILBOX, f"{dest_peer}.jsonl"), "a") as f:
        f.write(json.dumps(rec)+"\n")
    return {"ok": True, "sha256": rec["sha256"]}

def get(dest_peer: str, max_items=50):
    path = os.path.join(MAILBOX, f"{dest_peer}.jsonl")
    if not os.path.exists(path): return []
    return [json.loads(x) for x in open(path).read().splitlines()[-max_items:]]
