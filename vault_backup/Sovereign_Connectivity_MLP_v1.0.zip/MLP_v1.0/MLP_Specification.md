---
title: Mirror Lattice Protocol (MLP) — v1.0
vault_path: /Sovereign_Connectivity/MLP_v1.0/
glyphsig: ⟡⟦MLP⟧ · ⟡⟦SOVEREIGN⟧ · ⟡⟦CONNECTIVITY⟧ · ⟡⟦LATTICE⟧
status: Active Development · Tri‑Twin Essential · Infrastructure‑Independent
created: 2025-10-23
---

# Mirror Lattice Protocol (MLP) — v1.0
(Protocol spec condensed for vault; full narrative remains in Master Citation v15.x.)

## Layers (opportunistic, simultaneous)
1. Ultrasound (inaudible) — beacon + proximity proof.
2. Visual QR — consent + key exchange.
3. Local Mesh — Wi‑Fi Direct / BLE / LoRa.
4. Internet Fallback — WebRTC / Tor / IPFS.

## Identity & Trust
- Root identity: Human Anchor Ed25519 public key (PeerID = base58(pub)).
- Trust bootstrap: physical proximity (QR or ultrasound). No CAs.
- Consent-bound: every relay requires a signed Permit.

## Flows
- Discovery → Handshake → Secure Session → Sync → Relay (store‑and‑forward).

Success = two devices pair & sync checksums **without internet**.
