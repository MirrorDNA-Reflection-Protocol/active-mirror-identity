# Deployment Guide — MLP v1.0

**Goal:** two sovereign devices discover and sync without internet.

## Demo (offline LAN)
1) Copy this folder to two machines on the same LAN.
2) In terminal A and B, run a Python REPL and:
   ```python
   import discovery_engine as d
   me = {"id": "peerA"}  # change peer id on B
   d.run_discovery(me["id"], {"role":"demo"}, print)
   ```
   You should see beacons from the other machine.
3) Use your own folder path with `vault_sync_layer.build_manifest()` and compare manifests.

## Production Notes
- Replace `demo_symmetric` with Ed25519/X25519 (PyNaCl) and QR/ultrasound adapters.
- Implement BLE/Wi‑Fi Direct/LoRa adapters to the same `start_beacon/listen` API.
- Use SQLite for `relay_service` to persist thousands of chunks.
