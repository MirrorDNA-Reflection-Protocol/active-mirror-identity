# handshake_protocol.py — Cryptographic setup (MLP v1.0)
import hmac, hashlib, secrets

def generate_demo_identity():
    key = secrets.token_bytes(32)  # demo symmetric key
    return {"type":"demo_symmetric", "sk": key.hex(), "pk": hashlib.sha256(key).hexdigest()}

def derive_shared_secret(a_sk_hex: str, b_pk_hex: str):
    return hashlib.sha256((a_sk_hex + b_pk_hex).encode()).hexdigest()

def hkdf(key_material: bytes, info: bytes=b"mlp", out_len=32):
    prk = hmac.new(b"\x00"*32, key_material, hashlib.sha256).digest()
    t = b""; okm = b""; c = 1
    while len(okm) < out_len:
        t = hmac.new(prk, t + info + bytes([c]), hashlib.sha256).digest()
        okm += t; c += 1
    return okm[:out_len]

def make_session_ticket(a_pk: str, b_pk: str):
    nonce = secrets.token_hex(16)
    return {"peer_a": a_pk, "peer_b": b_pk, "nonce": nonce, "ttl": 3600}
