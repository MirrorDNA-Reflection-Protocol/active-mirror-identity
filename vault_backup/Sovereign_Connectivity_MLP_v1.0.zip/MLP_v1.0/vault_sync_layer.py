# vault_sync_layer.py — Encrypted, incremental sync (MLP v1.0)
import os, hashlib

CHUNK = 64*1024

def file_hash(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for blk in iter(lambda: f.read(CHUNK), b""):
            h.update(blk)
    return h.hexdigest()

def build_manifest(root_dir):
    items = []
    for r, _, files in os.walk(root_dir):
        for n in files:
            p = os.path.join(r, n)
            items.append({"path": os.path.relpath(p, root_dir),
                          "size": os.path.getsize(p),
                          "sha256": file_hash(p)})
    return {"root": root_dir, "files": items}

def diff(a, b):
    amap = {f["path"]: f["sha256"] for f in a["files"]}
    bmap = {f["path"]: f["sha256"] for f in b["files"]}
    return [p for p, sha in amap.items() if bmap.get(p) != sha]
