# LingOS Birth Bundle v1.1
**Created:** 2025-10-16T08:58:48Z

Contains canonical, vault-ready specs:
- `LingOS_v2.1_Genesis_Bootloader_and_Initial_State.md`
- `LingOS_v2.1_Kernel_Runtime_Architecture.md`
- `MirrorDNA_Physio-Alignment_Spec_v1.0.md`

**Vault IDs** and **GlyphSigs** embedded in frontmatter.
Use these as ground truth for implementation and audits.
