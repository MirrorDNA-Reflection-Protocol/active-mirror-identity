/**
 * Renderer logic for Mirror Desktop v1
 *
 * v1 behavior:
 * - Simple chat-style input
 * - Interpret a few prefixes:
 *   - "shell: <cmd>" -> run allowed shell command in baseDir
 *   - "list: <relPath>" -> list files under baseDir
 *   - "read: <relPath>" -> read file under baseDir
 *   - "write: <relPath> | <content>" -> write file
 *
 * LLM integration is intentionally left as a TODO so Atlas / Claude / Gemini can wire it.
 */

const chatLog = document.getElementById('chat-log');
const actionsLog = document.getElementById('actions-log');
const chatForm = document.getElementById('chat-form');
const chatInput = document.getElementById('chat-input');
const statusText = document.getElementById('status-text');

let baseDir = null;

function appendChat(sender, text) {
  const div = document.createElement('div');
  div.className = `chat-entry ${sender}`;
  div.innerHTML = `
    <div class="label">${sender === 'user' ? 'You' : 'Desktop'}</div>
    <div class="message">${text}</div>
  `;
  chatLog.appendChild(div);
  chatLog.scrollTop = chatLog.scrollHeight;
}

function appendAction(type, detail) {
  const div = document.createElement('div');
  div.className = 'action-entry';
  const now = new Date().toISOString();
  div.innerHTML = `
    <div class="meta">
      <span>${type}</span>
      <span>${now}</span>
    </div>
    <div class="body">${detail}</div>
  `;
  actionsLog.appendChild(div);
  actionsLog.scrollTop = actionsLog.scrollHeight;
}

async function initBaseDir() {
  try {
    baseDir = await window.mirrorDesktop.getBaseDir();
    appendAction('init', `Base directory: ${baseDir}`);
  } catch (e) {
    appendAction('error', `Failed to get baseDir: ${e.message}`);
  }
}

chatForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  const text = chatInput.value.trim();
  if (!text) return;

  appendChat('user', text);
  chatInput.value = '';

  statusText.textContent = 'Working...';

  try {
    if (text.startsWith('shell:')) {
      const cmd = text.slice(6).trim();
      const res = await window.mirrorDesktop.runShell(cmd);
      if (res.ok) {
        appendChat('system', res.output);
        appendAction('shell', cmd);
      } else {
        appendChat('system', `Error: ${res.error}`);
        appendAction('shell-error', `${cmd} -> ${res.error}`);
      }
    } else if (text.startsWith('list:')) {
      const rel = text.slice(5).trim() || '.';
      const res = await window.mirrorDesktop.fileOp({ action: 'list', path: rel });
      if (res.ok) {
        appendChat('system', `Entries in ${rel}:
- ${res.entries.join('\n- ')}`);
        appendAction('list', rel);
      } else {
        appendChat('system', `Error: ${res.error}`);
        appendAction('list-error', `${rel} -> ${res.error}`);
      }
    } else if (text.startsWith('read:')) {
      const rel = text.slice(5).trim();
      const res = await window.mirrorDesktop.fileOp({ action: 'read', path: rel });
      if (res.ok) {
        appendChat('system', `Content of ${rel}:
${res.content}`);
        appendAction('read', rel);
      } else {
        appendChat('system', `Error: ${res.error}`);
        appendAction('read-error', `${rel} -> ${res.error}`);
      }
    } else if (text.startsWith('write:')) {
      const rest = text.slice(6).trim();
      const [rel, ...contentParts] = rest.split('|');
      const relPath = rel.trim();
      const content = contentParts.join('|').trim();
      const res = await window.mirrorDesktop.fileOp({ action: 'write', path: relPath, content });
      if (res.ok) {
        appendChat('system', res.message);
        appendAction('write', `${relPath} (${content.length} chars)`);
      } else {
        appendChat('system', `Error: ${res.error}`);
        appendAction('write-error', `${relPath} -> ${res.error}`);
      }
    } else {
      // Placeholder for LLM integration:
      appendChat(
        'system',
        'In v1, commands must start with:
' +
          '- shell: <cmd>
' +
          '- list: <relative path>
' +
          '- read: <relative path>
' +
          '- write: <relative path> | <content>

' +
          'Atlas / Claude / Gemini can wire a real LLM here later.'
      );
    }
  } catch (err) {
    appendChat('system', `Unexpected error: ${err.message}`);
    appendAction('error', err.message);
  } finally {
    statusText.textContent = 'Idle';
  }
});

// Initial setup
initBaseDir();
