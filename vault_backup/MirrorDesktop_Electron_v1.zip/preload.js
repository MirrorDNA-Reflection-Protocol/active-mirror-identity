/**
 * Mirror Desktop v1 — preload script
 *
 * Expose a safe, minimal API to the renderer.
 */

const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('mirrorDesktop', {
  getBaseDir: () => ipcRenderer.invoke('mirror:getBaseDir'),
  runShell: (command) => ipcRenderer.invoke('mirror:runShell', command),
  fileOp: (op) => ipcRenderer.invoke('mirror:fileOp', op)
});
