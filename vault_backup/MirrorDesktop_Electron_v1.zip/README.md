# Mirror Desktop v1 (Electron)

A minimal, working starting point for your **Claude-style AI desktop app**.

This is intentionally simple:
- Electron shell
- Chat-style UI
- Safe OS bridge limited to:
  - `ls` / `pwd` in a base directory
  - basic file list/read/write/mkdir under that base directory
- Clear extension points for Claude Code, Atlas (ChatGPT), and Gemini 3 to turn this into a full AI desktop.

> Think of this as: **"Claude Desktop, but tiny and yours"** — ready to be expanded.

---

## 1. Setup

1. Unzip this folder somewhere, for example:

   ```bash
   mkdir -p ~/Projects
   cd ~/Projects
   unzip MirrorDesktop_Electron_v1.zip
   cd MirrorDesktop_Electron_v1
   ```

2. Install dependencies:

   ```bash
   npm install
   ```

3. (Optional but recommended) create your base directory:

   ```bash
   mkdir -p ~/MirrorHome
   ```

4. Copy `config.example.json` to `config.json` and set your username/path:

   ```bash
   cp config.example.json config.json
   # then edit config.json and set "baseDir" to your actual path, e.g.
   # "/Users/paul/MirrorHome"
   ```

5. Run the app:

   ```bash
   npm start
   ```

You should see the Mirror Desktop v1 window.

---

## 2. How to use v1

The chat input understands a few **prefix commands**:

- `shell: ls`  
  Runs `ls` in your configured base directory.

- `shell: pwd`  
  Shows the base directory path.

- `list: .`  
  Lists entries in the base directory.

- `list: notes`  
  Lists entries in `baseDir/notes`.

- `read: notes/today.md`  
  Reads that file (if it exists).

- `write: notes/today.md | Hello, Mirror Desktop!`  
  Writes content into that file (creating it if needed).

> v1 deliberately **does not support delete**.  
> Claude / Gemini can add that later with explicit confirmation flows.

---

## 3. Where the important pieces are

- `main.js`  
  Creates the window and wires IPC bridges.

- `preload.js`  
  Exposes `mirrorDesktop` API to the renderer in a safe way.

- `tools.js`  
  Node-side "OS bridge":
  - reads `config.json` (baseDir)
  - ensures paths stay inside baseDir
  - implements shell + file operations

- `src/index.html` / `src/style.css`  
  The chat UI + layout.

- `src/renderer.js`  
  Frontend logic:
  - handles user input
  - calls `mirrorDesktop.runShell` and `mirrorDesktop.fileOp`
  - displays outputs and simple logs

---

## 4. How to involve Claude Code

Open this project folder in **Claude Desktop** and tell it something like:

> "You are my engineering assistant. This is Mirror Desktop v1, a minimal Claude-style app.  
> 
> 1. Read main.js, preload.js, tools.js, and src/renderer.js.  
> 2. Explain to me, briefly, how it works.  
> 3. Then propose the next 3 safe extensions, such as:  
>    - adding a simple command history,  
>    - exposing a 'recent files' view,  
>    - or wiring a basic call to a local LLM HTTP endpoint (e.g. LM Studio) inside renderer.js.  
> 4. Do not add destructive operations yet. Keep everything reversible and safe."

You can then approve changes step by step.

---

## 5. How to involve Atlas (ChatGPT) and Gemini 3

You can ask Atlas (here) to:

- Design the **LLM integration layer** (how to call LM Studio, OpenAI, or Gemini APIs from renderer.js)
- Draft better UI flows (modes, prompts, quick actions)
- Define safety rules (what is allowed, what requires confirmation)

You can ask Gemini 3 to:

- Polish JS/TS code  
- Add types (if you move to TypeScript)  
- Add tests  
- Improve error handling  
- Improve packaging and distribution for macOS

---

## 6. Next obvious extensions

Ideas for Claude Code / Gemini to implement after v1:

1. **LLM integration**
   - Add a "free text" mode which sends the user’s message to a configured LLM endpoint.
   - Let the LLM suggest which `shell:` / `list:` / `read:` / `write:` commands to run.
   - Always show the planned commands and ask for approval.

2. **Command history & replay**
   - Right pane could list recent commands and let you click to re-run.

3. **Profiles / modes**
   - DEV mode (repos + tools)
   - OPS mode (cleanup, organization)
   - REFLECT mode (notes in a `reflections` folder)

4. **App launcher**
   - New tool in `tools.js` to open VSCode, Obsidian, browser, etc., with a safe allow-list.

This gives you a **clear, working base** that other models can refine toward the 99.9% production-grade experience you’re aiming for.
