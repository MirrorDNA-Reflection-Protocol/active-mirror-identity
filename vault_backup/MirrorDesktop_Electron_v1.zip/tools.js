/**
 * tools.js — minimal OS bridge for Mirror Desktop v1
 *
 * IMPORTANT:
 * - This is intentionally conservative.
 * - Only a very small set of safe commands are allowed by default.
 * - Claude / Gemini can extend this with more tools, with your approval.
 */

const { exec } = require('child_process');
const fs = require('fs');
const path = require('path');
const os = require('os');

const CONFIG_PATH = path.join(__dirname, 'config.json');
const DEFAULT_BASE_DIR = path.join(os.homedir(), 'MirrorHome');

/**
 * Load baseDir from config.json if present, else fallback.
 */
function getBaseDir() {
  try {
    if (fs.existsSync(CONFIG_PATH)) {
      const raw = fs.readFileSync(CONFIG_PATH, 'utf-8');
      const parsed = JSON.parse(raw);
      if (parsed.baseDir && typeof parsed.baseDir === 'string') {
        return parsed.baseDir;
      }
    }
  } catch (e) {
    // ignore and fall back
  }
  return DEFAULT_BASE_DIR;
}

/**
 * Ensure a requested path stays inside baseDir.
 */
function resolveSafePath(targetPath) {
  const baseDir = getBaseDir();
  const absBase = path.resolve(baseDir);
  const absTarget = path.resolve(baseDir, targetPath || '.');

  if (!absTarget.startsWith(absBase)) {
    throw new Error('Path escapes baseDir. Operation blocked.');
  }
  return absTarget;
}

/**
 * Run a very limited set of shell commands for now.
 * Allowed: 'ls', 'pwd' within baseDir context.
 */
function runShellCommand(command) {
  return new Promise((resolve) => {
    if (!command || typeof command !== 'string') {
      return resolve({ ok: false, error: 'No command provided.' });
    }

    const trimmed = command.trim();
    const baseDir = getBaseDir();
    const cwd = baseDir;

    // Simple allow-list
    const allowedPrefixes = ['ls', 'pwd'];
    const isAllowed = allowedPrefixes.some(p => trimmed === p || trimmed.startsWith(p + ' '));

    if (!isAllowed) {
      return resolve({
        ok: false,
        error: `Command not allowed yet in v1. Allowed prefixes: ${allowedPrefixes.join(', ')}`
      });
    }

    exec(trimmed, { cwd }, (error, stdout, stderr) => {
      if (error) {
        return resolve({ ok: false, error: stderr || error.message });
      }
      resolve({ ok: true, output: stdout || '(no output)' });
    });
  });
}

/**
 * File operations limited to baseDir.
 * op = { action, path, content? }
 */
function fileOperation(op) {
  return new Promise((resolve) => {
    try {
      const action = op?.action;
      const relPath = op?.path || '.';
      const absPath = resolveSafePath(relPath);

      if (!action) {
        return resolve({ ok: false, error: 'Missing file action.' });
      }

      if (action === 'list') {
        fs.readdir(absPath, (err, entries) => {
          if (err) return resolve({ ok: false, error: err.message });
          return resolve({ ok: true, entries });
        });
        return;
      }

      if (action === 'read') {
        fs.readFile(absPath, 'utf-8', (err, data) => {
          if (err) return resolve({ ok: false, error: err.message });
          return resolve({ ok: true, content: data });
        });
        return;
      }

      if (action === 'write') {
        const content = op?.content || '';
        fs.writeFile(absPath, content, 'utf-8', (err) => {
          if (err) return resolve({ ok: false, error: err.message });
          return resolve({ ok: true, message: `Wrote ${content.length} chars to ${relPath}` });
        });
        return;
      }

      if (action === 'mkdir') {
        fs.mkdir(absPath, { recursive: true }, (err) => {
          if (err) return resolve({ ok: false, error: err.message });
          return resolve({ ok: true, message: `Created directory ${relPath}` });
        });
        return;
      }

      // No delete yet in v1
      if (action === 'delete') {
        return resolve({ ok: false, error: 'Delete not enabled in v1. Add with explicit confirmation later.' });
      }

      return resolve({ ok: false, error: `Unknown file action: ${action}` });
    } catch (e) {
      return resolve({ ok: false, error: e.message });
    }
  });
}

module.exports = {
  getBaseDir,
  runShellCommand,
  fileOperation
};
