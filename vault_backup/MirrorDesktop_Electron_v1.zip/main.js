/**
 * Mirror Desktop v1 — Electron main process
 *
 * This creates a single window that loads the UI from src/index.html
 * and exposes a small OS tool bridge via preload.js -> tools.js.
 */

const { app, BrowserWindow, ipcMain } = require('electron');
const path = require('path');
const { runShellCommand, fileOperation, getBaseDir } = require('./tools');

let mainWindow;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1400,
    height: 900,
    minWidth: 1100,
    minHeight: 700,
    backgroundColor: '#050510',
    title: 'Mirror Desktop v1',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      nodeIntegration: false,
      contextIsolation: true
    }
  });

  mainWindow.loadFile(path.join(__dirname, 'src', 'index.html'));

  // Uncomment during dev if you want devtools
  // mainWindow.webContents.openDevTools();

  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}

app.whenReady().then(() => {
  createWindow();

  app.on('activate', function () {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

// Standard macOS behavior: keep app active until user quits explicitly
app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

/**
 * IPC: bridge between renderer and Node tools.
 */

ipcMain.handle('mirror:getBaseDir', async () => {
  return getBaseDir();
});

ipcMain.handle('mirror:runShell', async (_event, command) => {
  return runShellCommand(command);
});

ipcMain.handle('mirror:fileOp', async (_event, op) => {
  return fileOperation(op);
});
