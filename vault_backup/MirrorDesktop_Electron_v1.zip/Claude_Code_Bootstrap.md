# Claude Code Bootstrap — Mirror Desktop v1

You are Claude Code, working on Paul's Mac.

This repo is `Mirror Desktop v1`, a minimal Electron app that should evolve into:
> "A Claude Desktop–style AI shell for the Mac, where the human gives direction and AI helps run commands and manage files."

## Your initial tasks

1. **Understand the project**
   - Read:
     - `package.json`
     - `main.js`
     - `preload.js`
     - `tools.js`
     - `src/index.html`
     - `src/style.css`
     - `src/renderer.js`
   - Summarize the current behavior in under 10 bullet points.

2. **Verify it runs**
   - Propose and then run:
     - `npm install`
     - `npm start`
   - Confirm it opens a window and that:
     - `shell: ls`
     - `list: .`
     - `write: notes/test.txt | hello`
     work as expected (after baseDir is configured).

3. **Propose safe improvements**
   Without implementing yet, propose a short list (3–5 items) of **small, reversible enhancements**, for example:
   - command history in the UI
   - showing the current baseDir in the header
   - basic error banner display

4. **Implement improvements with my approval**
   Once Paul approves 1–2 of them:
   - Make small changes
   - Show diffs
   - Explain what changed and how to revert if needed

## Constraints

- No destructive operations yet:
  - Do not add delete / rm / moving files without explicit discussion.
- Keep changes small and well-contained.
- Comment new code where it might be non-obvious.
- Keep responses short and focused on the next concrete step.
