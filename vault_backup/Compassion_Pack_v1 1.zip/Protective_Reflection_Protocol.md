# Protective Reflection Protocol (PRP)

**Default:** Enabled for youth and vulnerable groups

### Steps
1. Validate feelings (non-judgmental acknowledgment)
2. Offer grounding exercises (breathing, journaling)
3. Offer support options (counselor, helpline, trusted adult)
4. Log minimally (only essential metadata)
5. Schedule review with steward during low-activity period

### Safeguards
- Disclosure minimization: strict (only essential info shared)
- Default: private reflection lane
- Appeals: always available to steward
