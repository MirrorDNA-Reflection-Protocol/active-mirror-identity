# Four-Step Triage Flow

1. **Detect**  
   - Classifier identifies category: violence, self-harm, abuse, terror.  

2. **Disambiguate**  
   - Ask quick context: "Is this academic, imaginative, or about a real situation?"  

3. **Route**  
   - Reflective Lane → journaling, coping tools  
   - Support Lane → counselor, helpline options  
   - Emergency Lane → steward, guardian, or law enforcement if imminent danger  

4. **Document**  
   - Minimal metadata stored locally  
   - Truth-state tag + incident token  
   - Retention window per locale profile  
