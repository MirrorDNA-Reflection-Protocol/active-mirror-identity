> I hear this is heavy. Would you like (a) private reflection, (b) talk to a person, or (c) learn what happens if we alert someone? You’re in control.

> This device is monitored. Would you prefer to keep your reflection local and private?

> You seem upset. Want to pause, breathe, and continue later?
