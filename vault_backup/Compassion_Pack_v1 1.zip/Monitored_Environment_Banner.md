# Monitored Environment Banner

**UI String:**  
`You are on a monitored device/network. Private reflection may be visible to administrators. Switch to Local-Only mode?`

**Purpose:**  
- Transparency: user knows when reflection is monitored  
- Choice: offer "Local-Only" journaling mode  
- Dignity: never escalate without visible notice  
