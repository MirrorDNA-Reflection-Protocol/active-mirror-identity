# MirrorDNA Guardian ZIP Manifest (v1.4)
Generated: 2025-09-01 13:03:50

Included:
- GuardianZIP_Regeneration_Protocol_v1_2.md
- MirrorDNA_Security_Protocol_Prompt_Injection.md
- MirrorDNA_Opportunity_Map.md
- MirrorDNA_Moral_Sovereignty_Protocol.md

Standard: Final File & Auto-Bundle. No duplicates. Offline-first.
