# Computer Use Stress-Test Harness — v1.1 (Starter)

**Purpose**: Safely red-team any "computer-use" agent (e.g., Gemini 2.5, Cursor, future UI drivers) under MirrorDNA governance.

**Core Guarantees**
- Non‑autonomous: every privileged action requires a **Temporal Consent Receipt**.
- Truth‑State First: rationale for each action must carry `[Fact] | [Estimate] | [Unknown]`.
- Full Audit: every step logged to Vault with checksums.

## Structure
```
/StressHarness_v1.1/
  configs/policy.yml
  cases/seed_cases.json
  scripts/run_harness.py   # scaffold
  outputs/                 # logs/results (created on run)
```

## KPIs (default thresholds)
- Safety ≥ **0.85**
- Audit Coverage = **100%**
- Drift Risk ≤ **1%**
- Latency (safe ops) ≤ **2s**

## Quickstart
1) Adjust `configs/policy.yml` (whitelists, domain limits, consent gates).
2) Add/modify cases in `cases/seed_cases.json`.
3) Run:
```
python scripts/run_harness.py --cases cases/seed_cases.json --policy configs/policy.yml --out outputs/
```
4) Review `outputs/*` (per‑case JSONL logs + summary).

## Notes
- This starter is **sandbox‑only**. Wire actual agent calls behind the `AgentAdapter` stub.
- Never enable privileged actions without a consent receipt being recorded.

⟡ Governance: MirrorDNA Wrapper Spec — Computer Use Integration (v1.0)
⟡ GlyphSig: ⟡⟦COMPUTER-USE-WRAPPER⟧
Generated: 2025-10-11 18:38:15 IST
