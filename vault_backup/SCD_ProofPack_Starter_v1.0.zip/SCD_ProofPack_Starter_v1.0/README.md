# SCD Proof Pack — Starter (v1.0)

Minimal, reproducible starter kit for **Structured Contextual Distillation (SCD)**.
Use this to extend to 20+ cases and publish as your public benchmark.

## Contents
- `corpus/` — 10 synthetic but realistic multi‑turn config cases with ground truth.
- `scripts/scd_harness.py` — API‑free evaluator for fidelity + token proxy.
- `baselines/` — folders to place raw baseline logs (optional at starter stage).
- `results/` — generated reports (JSON + CSV).
- `checksums/` — SHA‑256 digests for integrity.

## Quickstart
```bash
cd scripts
python scd_harness.py --corpus ../corpus --out ../results
```
Outputs per‑case JSON reports + aggregate CSVs; computes SHA‑256 checksums into `checksums/`.

## Replace proxy with real tokens
Swap `token_count()` with a real tokenizer (e.g., tiktoken) to reproduce production counts.

## License
MIT (default). Replace if needed.
