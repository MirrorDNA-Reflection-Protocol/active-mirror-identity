Run `python scd_harness.py --corpus ../corpus --out ../results`
