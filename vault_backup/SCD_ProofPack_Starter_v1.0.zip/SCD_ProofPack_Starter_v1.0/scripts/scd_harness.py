import json, argparse, os, csv
from pathlib import Path

def token_count(s: str) -> int:
    # Proxy: UTF-8 bytes. Swap for a real tokenizer in production.
    return len(s.encode("utf-8"))

def apply_supersession(turns):
    state = {}
    for step in sorted(turns, key=lambda x: x["t"]):
        for k, v in step["update"].items():
            state[k] = v
    return state

def jaccard_kv(a: dict, b: dict) -> float:
    def flatten(d):
        out = {}
        for k, v in d.items():
            out[k] = json.dumps(v, sort_keys=True) if isinstance(v, (dict, list)) else str(v)
        return out
    A, B = flatten(a), flatten(b)
    keys = set(A) | set(B)
    inter = sum(1 for k in keys if (k in A and k in B and A[k] == B[k]))
    return inter/len(keys) if keys else 1.0

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--corpus", required=True)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()

    Path(args.out).mkdir(parents=True, exist_ok=True)

    reports = []
    for p in sorted(Path(args.corpus).glob("*.json")):
        data = json.loads(p.read_text())
        turns = data["turns"]
        gt = data["ground_truth"]

        scd = apply_supersession(turns)
        fid = jaccard_kv(scd, gt)

        # Token proxy: baseline = full history json; scd = final state json
        history_blob = json.dumps(turns, sort_keys=True)
        fct_tokens = token_count(history_blob)
        scd_tokens = token_count(json.dumps(scd, sort_keys=True))
        reduction = 1 - (scd_tokens / max(1, fct_tokens)) if fct_tokens else 0.0

        rep = {
            "case": p.stem,
            "fidelity_jaccard": round(fid, 6),
            "baseline_tokens_proxy": fct_tokens,
            "scd_tokens_proxy": scd_tokens,
            "reduction_proxy": round(reduction, 6)
        }
        reports.append(rep)

        (Path(args.out)/f"{p.stem}_report.json").write_text(json.dumps(rep, indent=2))

    # CSV aggregates
    with open(Path(args.out)/"fidelity_scores.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["case", "fidelity_jaccard"])
        w.writeheader()
        for r in reports:
            w.writerow({"case": r["case"], "fidelity_jaccard": r["fidelity_jaccard"]})

    with open(Path(args.out)/"token_efficiency.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["case", "baseline_tokens_proxy", "scd_tokens_proxy", "reduction_proxy"])
        w.writeheader()
        for r in reports:
            w.writerow({
                "case": r["case"],
                "baseline_tokens_proxy": r["baseline_tokens_proxy"],
                "scd_tokens_proxy": r["scd_tokens_proxy"],
                "reduction_proxy": r["reduction_proxy"]
            })

    # Summary
    mean_f = sum(r["fidelity_jaccard"] for r in reports)/len(reports) if reports else 0.0
    mean_r = sum(r["reduction_proxy"] for r in reports)/len(reports) if reports else 0.0
    summary = {
        "num_cases": len(reports),
        "mean_fidelity_jaccard": round(mean_f, 6),
        "mean_token_reduction_proxy": round(mean_r, 6)
    }
    (Path(args.out)/"summary_stats.json").write_text(json.dumps(summary, indent=2))

if __name__ == "__main__":
    main()
