# VS Kernel Patch Note (v1.0)

## Insert after “## 2. Data Flow Specifications”
```diff
+### 2.1 VS Gate (optional)
+If `diversity_entropy(window=N) < τ`, the planner MUST emit a VS candidate set (K∈[2,5]),
+score (C,R,N,S), normalize → sample (deterministic if seed provided), then execute.
```

## Patch the pipeline
```diff
 def execute_glyph_packet(packet: CBOR) -> Result:
     verify_signature(packet.header.source_key)
     normalized = normalize_glyphs(packet.payload)
     validate_syntax(normalized)
     validate_semantics(normalized)
-    gas = init_gas(packet.header.gas_limit)
-    charge_gas(gas, normalized)
-    result = GlyphVM.execute(normalized, gas)
+    gas = init_gas(packet.header.gas_limit)
+    charge_gas(gas, normalized)
+    if echo.diversity_entropy(window=N) < τ:
+        result = GlyphVM.execute_vs(normalized, k=K, seed=vs_seed(), gas=gas)
+    else:
+        result = GlyphVM.execute(normalized, gas)
     semantic_lattice.update(result)
     echo_lattice.log_execution(packet, result)
     return result
```

## Defaults / Params
```diff
+VS defaults: τ=0.65 (entropy 0–1), K=3, min_safety=0.80, α=0.5, β=0.2, γ=0.2, δ=0.1
+Deterministic replay seed = H(VaultID || SA_root || nonce)
+VS telemetry: store `weights_hash`, `choice`, `vs_seed`, `K`, `anchors`
```
