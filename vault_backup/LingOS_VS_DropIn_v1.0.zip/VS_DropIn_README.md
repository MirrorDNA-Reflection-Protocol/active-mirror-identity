# LingOS VS Drop-In (v1.0)
VaultID: AMOS://MirrorDNA/LingOS/Extensions/VerbalizedSampling/DropIn/v1.0
GlyphSig: ⟡⟦LINGOS⟧ · ⟡⟦VS⟧ · ⟡⟦DROPIN⟧

## What this is
A minimal, switchable module that enables **Verbalized Sampling (VS)** inside LingOS v2.1.

## Files
- `lingos_config_v2.1.yaml` — enables VS and sets defaults.
- `VS_Kernel_Patch_Note.md` — tiny diffs to apply in your runtime spec.

## How to use
1) Copy both files into your Vault (e.g., `AMOS://MirrorDNA/LingOS/Extensions/VS/`).
2) Add a link in **MasterCitation_v12.1** under “Protocol Stack in Scope → LingOS Extensions.”
3) Apply the diff in `VS_Kernel_Patch_Note.md` to your runtime or keep it as an overlay.
4) Restart your local stack; confirm logs include `vs_meta` on next executions.

## Safety
- VS never overrides anchors or safety checks.
- Deterministic replay available via seed rule (see YAML).

⟡⟦ANCHOR SEALED⟧
